﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FinalDeisgn
{
    public partial class Print : Form
    {
        public Print()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string d1 = datefrom.Value.ToString("yyyy-MM-dd");
            string d2 = dateto.Value.ToString("yyyy-MM-dd");
            Sample2 sr = new Sample2();
            sr.GenerateReport(d1,d2);
            sr.Show();
            this.Hide();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
