﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
namespace FinalDeisgn
{
    public partial class Staff : Form
    {


        MySqlConnection con = new MySqlConnection(@"Data Source=localhost;port=3306;Initial Catalog=dbstaff;User Id=root;password=''");
        MySqlDataReader dr;
        MySqlCommand cmd = new MySqlCommand();

        public string user;
        public string role1;

        public Staff(string role)
        {
            InitializeComponent();
            getRole(role);
            
        }
        public void getRole(string role)
        {

            role1 = role;



        }

        private void Staff_Load(object sender, EventArgs e)
        {
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM  tblstaff ";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            try
            {
                
                MemoryStream ms = new MemoryStream();
                pbImage.Image.Save(ms, pbImage.Image.RawFormat);
                byte[] img = ms.ToArray();
                con.Open();
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "INSERT INTO `tblstaff`(`Firstname`, `Lastname`, `MI`, `Street`, `Barangay`, `City`, `Province`, `ContactNo`, `Username`, `Password`, `Role` , `Date`, `Image`)     values ('" + txtFirstname.Text + "','" + txtLastname.Text + "','" + txtMI.Text + "','" + txtStreet.Text + "','" + txtBarangay.Text + "','" + txtCity.Text + "','" + txtProvince.Text + "','" + txtContractNo.Text + "','" + txtUsername.Text + "','" + txtPassword.Text + "','" + cbRole.Text + "','" + dtpDate.Text + "',@pbImage)";
                cmd.Parameters.Add("@pbImage", MySqlDbType.Blob);
                cmd.Parameters["@pbImage"].Value = img;
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Staff Succesfully Inserted");
                txtLastname.Text = "";
                txtFirstname.Text = "";
                txtMI.Text = "";
                txtContractNo.Text = "";
                txtProvince.Text = "";
                txtStreet.Text = "";
                txtBarangay.Text = "";
                txtCity.Text = "";
                txtUsername.Text = "";
                txtPassword.Text = "";
                txtConfirmPs.Text = "";
                cbRole.Text = "";

               
            }
            catch (Exception ex)
            {
                return;
                
            }
            finally {
                MessageBox.Show(" Missing Field ");
                txtLastname.Text = "";
                txtFirstname.Text = "";
                txtMI.Text = "";
                txtContractNo.Text = "";
                txtProvince.Text = "";
                txtStreet.Text = "";
                txtBarangay.Text = "";
                txtCity.Text = "";
                txtUsername.Text = "";
                txtPassword.Text = "";
                txtConfirmPs.Text = "";
                //Form1 st = new Form1(role1);
                //st.Show();
            }
        }

        private void linkBrowse_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            string imgLoc = "";
            //bool isCLicked = false;
            open.Filter = "Image files (*.jpg)|*.jpg|(*.png)|*.png|(*.gif)|*.gif";
            open.Title = "Select Employee Profile Picture";
            if (open.ShowDialog() == DialogResult.OK)
            {
                imgLoc = open.FileName;
                pbImage.ImageLocation = imgLoc;
                //  isCLicked = true;
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM  tblstaff ";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        private void display() {

            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM  tblstaff ";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Are you sure to delete this product ?", "Delete", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {
                con.Open();
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "DELETE FROM `tblstaff` where `ID` = '" + txtID.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                MessageBox.Show("Record Deleted");
                con.Close();
                display();
            }
             
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "UPDATE `tblstaff` SET `Firstname`='" + txtFirstname.Text + "',`Lastname`='" + txtLastname.Text + "',`MI`='" + txtMI + "',`Street`='" + txtStreet + "',`Barangay`='" + txtBarangay.Text + "',`City`='" + txtCity + "',`Province`='" + txtProvince + "',`ContactNo`='" + txtContractNo + "',`Username`='" + txtUsername.Text + "',`Password`='" + txtPassword + "',`Role`='" + cbRole.Text + "',`Date`='" + dtpDate.Text + "',`Image`='" + pbImage.Image + "' where ID = '" + lblID.Text + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            MessageBox.Show("Product Sucessfully Updated");
            con.Close();
        }

        private void txtContractNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 11)
            {
                e.Handled = true;

            }
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                    txtFirstname.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                    txtFirstname.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                    txtLastname.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                    txtMI.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                    txtStreet.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                    txtBarangay.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                    txtCity.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
                    txtProvince.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
                    txtContractNo.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
                    txtUsername.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
                    txtPassword.Text = dataGridView1.CurrentRow.Cells[10].Value.ToString();
                    txtConfirmPs.Text = dataGridView1.CurrentRow.Cells[10].Value.ToString();
                    cbRole.Text = dataGridView1.CurrentRow.Cells[11].Value.ToString();
                    date.Text = dataGridView1.CurrentRow.Cells[12].Value.ToString();
                   
                    Byte[] img = (Byte[])dataGridView1.CurrentRow.Cells[13].Value;
                    MemoryStream ms = new MemoryStream(img);
                    pbImage.Image = Image.FromStream(ms);
                    //DataGridBoolColumn img = new DataGridBoolColumn();
                    //img = (DataGridBoolColumn)dataGridView1.Columns[13];
                   
                }

                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                    txtID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                }
            }
            catch (Exception ex)
            {
                return;
            }
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
        }

        private void txtConfirmPs_TextChanged(object sender, EventArgs e)
        {
            if (txtPassword.Text.Equals(txtConfirmPs.Text))
            {

                lblID.Text = "";
                btnInsert.Enabled = true;

            }
            else
            {

                lblID.Text = "Password did not match ! ";
                btnInsert.Enabled = false;
            }
        }

        private void lblID_Click(object sender, EventArgs e)
        {

        }

        private void GroupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void lblpass_Click(object sender, EventArgs e)
        {

        }

        private void txtContractNo_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void bunifuFlatButton1_Click_1(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Label9_Click(object sender, EventArgs e)
        {

        }

        private void flatGroupBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
