﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace FinalDeisgn
{
    public partial class frmDatabaseConfig : Form
    {
        public frmDatabaseConfig()
        {
            InitializeComponent();
        }
        private string TstServerMySQL;
        private string TstPortMySQL;
        private string TstUserNameMySQL;
        private string TstPwdMySQL;
        private string TstDBNameMySQL;


        
        

        private void cmdSave_Click(object sender, EventArgs e)
        {
            TstServerMySQL = txtServerHost.Text;
            TstPortMySQL = txtPort.Text;
            TstUserNameMySQL = txtUserName.Text;
            TstPwdMySQL = txtPassword.Text;
            TstDBNameMySQL = txtDatabase.Text;

            try
            {
                SQLConn.conn.ConnectionString = "Server = '" + TstServerMySQL + "';  " + "Port = '" + TstPortMySQL + "'; " + "Database = '" + TstDBNameMySQL + "'; " + "user id = '" + TstUserNameMySQL + "'; " + "password = '" + TstPwdMySQL + "'";
                SQLConn.conn.Open();

                SQLConn.DBNameMySQL = txtDatabase.Text;
                SQLConn.ServerMySQL = txtServerHost.Text;
                SQLConn.UserNameMySQL = txtUserName.Text;
                SQLConn.PortMySQL = txtPort.Text;
                SQLConn.PwdMySQL = txtPassword.Text;

                SQLConn.SaveData();
                this.Close();
            }
            catch
            {
                //Interaction.MsgBox("The system failed to establish a connection", MsgBoxStyle.Information, "Database Settings");
            }
            SQLConn.DisconnMy();
        }

        private void cmdTest_Click_1(object sender, EventArgs e)
        {
            //Test database connection

            TstServerMySQL = txtServerHost.Text;
            TstPortMySQL = txtPort.Text;
            TstUserNameMySQL = txtUserName.Text;
            TstPwdMySQL = txtPassword.Text;
            TstDBNameMySQL = txtDatabase.Text;


            try
            {
                SQLConn.conn.ConnectionString = "Server = '" + TstServerMySQL + "';  " + "Port = '" + TstPortMySQL + "'; " + "Database = '" + TstDBNameMySQL + "'; " + "user id = '" + TstUserNameMySQL + "'; " + "password = '" + TstPwdMySQL + "'";


                SQLConn.conn.Open();
                Interaction.MsgBox("The database is ready to use", MsgBoxStyle.Information, "Database Settings");

            }
            catch
            {
                Interaction.MsgBox("Connection failed, Install WAMP server first", MsgBoxStyle.Information, "Database Settings");

            }
            SQLConn.DisconnMy();
        }

        private void cmdClose_Click(object sender, EventArgs e)
        {

        }
    }
}
