﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using MySql.Data.MySqlClient;
using Microsoft.Reporting.WinForms;
using Microsoft.VisualBasic;

namespace FinalDeisgn
{
    public partial class ViewReport : Form
    {
         //DateTime ReportDate;

        public ViewReport(DateTime reportDate)
        {
            InitializeComponent();
            //ReportDate = reportDate;
        }

        private void ViewReport_Load(object sender, EventArgs e)
        {
              LoadReport();

            //this.reportViewer1.RefreshReport();
            //this.reportViewer1.RefreshReport();
        }


        private void LoadReport()
        {
        //    try
        //    {
        //        if (InvoiceSetting() == 1)
        //        {
        //            SQLConn.sqL = "SELECT CONCAT(Lastname, ', ', Firstname, ' ', MI) as StaffName, ProductCode, P.Description, REPLACE(TDate, '-', '/') as TDate, TTime,TD.ItemPrice, SUM(TD.Quantity) as totalQuantity, (TD.ItemPrice * SUM(TD.Quantity)) as TotalPrice  FROM Product as P, Transactions as T, TransactionDetails as TD, Staff as St WHERE P.ProductNo = TD.ProductNo AND TD.InvoiceNo = T.InvoiceNo AND St.StaffID = T.StaffID AND  TDate = '" + ReportDate.ToString("MM/dd/yyyy") + "' AND T.Status != 1 GROUP BY  St.StaffID, P.ProductNo, TDate ORDER By TDate";
        //        }
        //        else
        //        {
        //            SQLConn.sqL = "SELECT CONCAT(Lastname, ', ', Firstname, ' ', MI) as StaffName, ProductCode, P.Description, REPLACE(TDate, '-', '/') as TDate, TTime,TD.ItemPrice, SUM(TD.Quantity) as totalQuantity, (TD.ItemPrice * SUM(TD.Quantity)) as TotalPrice  FROM Product as P, Transactions as T, TransactionDetails as TD, Staff as St WHERE P.ProductNo = TD.ProductNo AND TD.InvoiceNo = T.InvoiceNo AND St.StaffID = T.StaffID AND  TDate = '" + ReportDate.ToString("MM/dd/yyyy") + "' GROUP BY  St.StaffID, P.ProductNo, TDate ORDER By TDate";
        //        }

        //        SQLConn.ConnDB();
        //        SQLConn.cmd = new MySqlCommand(SQLConn.sqL, SQLConn.conn);
        //        SQLConn.da = new MySqlDataAdapter(SQLConn.cmd);

        //        this.dsReportC.DailySalesByStaff.Clear();
        //        SQLConn.da.Fill(this.dsReportC.DailySalesByStaff);

        //        //this.CsService1.SetDisplayMode(DisplayMode.PrintLayout);
        //        //this.reportViewer1.ZoomPercent = 90;
        //        //this.reportViewer1.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.Percent;

        //        //this.reportViewer1.RefreshReport();

        //    }
        //    catch (Exception ex)
        //    {
        //        Interaction.MsgBox(ex.ToString());
        //    }
        //}
        //     int InvoiceSetting()
        //{
        //    int ret = 0;
        //    try
        //    {
        //        SQLConn.sqL = "SELECT ID FROM tblstaff";
        //        SQLConn.ConnDB();
        //        SQLConn.cmd = new MySqlCommand(SQLConn.sqL, SQLConn.conn);
        //        SQLConn.dr = SQLConn.cmd.ExecuteReader();


        //        if (SQLConn.dr.Read() == true)
        //        {
        //            ret = Convert.ToInt32(SQLConn.dr["ID"]);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Interaction.MsgBox(ex.ToString());
        //    }
        //    finally
        //    {
        //        SQLConn.cmd.Dispose();
        //        SQLConn.conn.Close();
        //    }

        //    return ret;
        }


        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
