﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace FinalDeisgn
{
    public partial class Pos : Form
    {


        MySqlConnection con = new MySqlConnection(@"Data Source=localhost;port=3306;Initial Catalog=dbstaff;User Id=root;password=''");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataReader dr;

        double Price;
        double Quantity;
        double Total;
        double Cash;
        double Change;
        double TotalAmount;
        double tot;
        string desc;


        public string user;
        public string role1;

        public Pos()
        {
            InitializeComponent();
        }

         private void GetTotal()
        {
            try
            {
                double total = 0;
                for (int i = 0; i < dataGridView3.Rows.Count-1; ++i)
                {
                  total += double.Parse(dataGridView3[4, i].Value.ToString());
                    
                }
                lblTotal.Text = total.ToString("#,##0.00");
                tot = total;
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
         }
         //private void DescTotal()
         //{
         //    string Desctotal;
         //    for (string i = 0; i < dataGridView1.Rows.Count - 1; ++i)
         //    {
         //        Desctotal += double.Parse(dataGridView1[1, i].Value.ToString());

         //    }

         //    all.Text = Desctotal.ToString();
         //}

        


        private void timer1_Tick(object sender, EventArgs e)
        {
            cbTime.Text = DateTime.Now.ToString("hh:mm tt");
        }

        private void bunifuMaterialTextbox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;

            }
        }

        private void bunifuMaterialTextbox2_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuMaterialTextbox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;

            }
        }

        private void cbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                cmd = new MySqlCommand("Select * from tblproduct where Category like '" + cbCategory.Text + "'", con);
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                dr = cmd.ExecuteReader();
                dr.Read();

                if (dr.HasRows)
                {
                    txtDesc.Text = dr.GetValue(1).ToString();
                    txtPrice.Text = dr.GetValue(2).ToString();
                    txtID.Text = dr.GetValue(0).ToString();
                    btnSettle.Enabled = true;


                }
                else
                {

                    MessageBox.Show("Product Not Found !");

                }
                con.Close();
            }
            catch (Exception ex)
            {
                return;
            }
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                txtPrice.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                txtID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                txtDesc.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                cbCategory.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new MySqlCommand("Select * from tblproduct where ProdDesc like '" + txtSearch.Text + "'", con);
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                dr = cmd.ExecuteReader();
                dr.Read();
                con.Close();
            }
            catch (Exception ex) { }
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {

            try
            {
                dataGridView3.Rows.Add(txtDesc.Text, txtPrice.Text, txtQuanity.Text, txtID.Text, double.Parse(txtPrice.Text) * int.Parse(txtQuanity.Text));
                GetTotal();
                txtQuanity.ResetText();
                //DescTotal();
            }
            catch (Exception ex)
            {
                MessageBox.Show("");
            }
        }

        private void txtCash_OnValueChanged(object sender, EventArgs e)
        {
             try
            {
                if (txtCash.Text == string.Empty)
                {
                    txtChange.Text = "P0.00";

                }
                else
                {
                    
                    Change = double.Parse(txtCash.Text) - tot;
                    txtChange.Text = Change.ToString("P#,##0.00");

                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
          }

        private void txtChange_OnValueChanged(object sender, EventArgs e)
        {
            
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            try
            {
                if (Change < 0)
                {
                    MessageBox.Show("NOT ENOUGH MONEY");
                    txtCash.ResetText();
                    btnSettle.Enabled = false;
                    btnSettle.Enabled = true;



                }

                else
                {
                    btnSettle.Enabled = true;
                    con.Open();
                    MySqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "INSERT INTO `tblmain`(`Price`, `Quantity`, `ProdID`,`ProdDesc`, `Catergory`,`DateSold`,`Time`,`Cash`, `TotalAmount`, `Change`) values ('" + txtPrice.Text + "','" + txtQuanity.Text + "','" + txtID.Text + "','" + txtDesc1.Text + "','" + cbCategory.Text + "','" + cbDate.Value.ToString("yyyy-MM-dd") + "','" + cbTime.Text + "','" + txtCash.Text + "','" + lblTotal.Text + "','" + txtChange.Text + "')";
                    cmd.ExecuteNonQuery();
                    con.Close();
                    txtDesc1.ResetText();
                    lblTotal.ResetText();
                    txtChange.ResetText();
                    txtCash.ResetText();
                    txtDesc.ResetText();
                    txtPrice.ResetText();
                    txtID.ResetText();
                    dataGridView3.RefreshEdit();
                    
                    GetTotal();
                    MessageBox.Show("Thanks for buying !");

                }
            }catch(Exception ex){
                return;
            }

           
        }
      private int a = 030000001;
        private void Pos_Load(object sender, EventArgs e)
        {
            
           
            con.Open();

            cmd = new MySqlCommand("Select * from tblproduct", con);
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dr = cmd.ExecuteReader();
            dr.Read();
         

            if (dr.HasRows)
            {
               
               // CusNo.Text = dr.GetValue(0).ToString();
                con.Close();

            }

            

        }

        private void txtChange_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;

            }
        }

        private void txtDesc_KeyPress(object sender, KeyPressEventArgs e)
        {
            MessageBox.Show("You Cannot Change the Description");
            txtDesc.Enabled = false;
           
        }

        private void txtID_KeyPress(object sender, KeyPressEventArgs e)
        {
            MessageBox.Show("You Cannot Change the ID Number");
            txtID.Enabled = false;
            Char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;

            }
        }

        private void txtDesc_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txtID_MouseClick(object sender, MouseEventArgs e)
        {
            MessageBox.Show("You Cannot Change the ID Number");
            txtID.Enabled = false;
        }

        private void txtDesc_MouseClick(object sender, MouseEventArgs e)
        {
            MessageBox.Show("You Cannot Change the ");
            txtDesc.Enabled = false;
        }

        private void txtDesc_Resize(object sender, EventArgs e)
        {
            MessageBox.Show("You Cannot Change the ");
            txtDesc.Enabled = false;
        }

        private void txtDesc_KeyDown(object sender, KeyEventArgs e)
        {
            MessageBox.Show("You Cannot Change the ");
            txtDesc.Enabled = false;
        }

        private void txtPrice_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;

            }
        }

        private void txtPrice_Resize(object sender, EventArgs e)
        {
            
        }

        private void txtPrice_DoubleClick(object sender, EventArgs e)
        {
           
        }

        private void CusNo_Click(object sender, EventArgs e)
        {
           
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtChange_Click(object sender, EventArgs e)
        {

        }

        private void lblTotal_Click(object sender, EventArgs e)
        {

        }
        private void Session()
        { 
            
        }
        //private void remove()
        //{

        //    dataGridView3.Rows.Remo(txtDesc.Text);
        //    dataGridView3.Rows.Remove(txtDesc.Text, txtPrice.Text, txtQuanity.Text, txtID.Text, double.Parse(txtPrice.Text) * int.Parse(txtQuanity.Text));
        //}
        int selectedRow;
        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {

            selectedRow = dataGridView3.CurrentCell.RowIndex;
            dataGridView3.Rows.RemoveAt(selectedRow);
            GetTotal();
             
           
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
       
        private void button2_Click(object sender, EventArgs e)
        {
            a++;
            CusNo.Text = a.ToString();
        }

        private void txtDesc_TextChanged_1(object sender, EventArgs e)
        {
            txtDesc1.Text += txtDesc.Text + " , ";
           

        }

        private void txtDesc1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }




        }
    }
