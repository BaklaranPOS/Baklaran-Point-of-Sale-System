﻿namespace FinalDeisgn
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pnlhi = new System.Windows.Forms.Panel();
            this.cbTime = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.sETTINGSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnSession = new System.Windows.Forms.ToolStripMenuItem();
            this.btnUser = new System.Windows.Forms.ToolStripMenuItem();
            this.databaseConfigurationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printSaleReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.flatMini3 = new FlatUI.FlatMini();
            this.lblTitle = new System.Windows.Forms.Label();
            this.formSkin1 = new FlatUI.FormSkin();
            this.panel1 = new System.Windows.Forms.Panel();
            this.flatClose1 = new FlatUI.FlatClose();
            this.lblDateTime = new System.Windows.Forms.Label();
            this.lbluser = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.MainPanel = new System.Windows.Forms.Panel();
            this.btnProduct = new Bunifu.Framework.UI.BunifuTileButton();
            this.btnStaff = new Bunifu.Framework.UI.BunifuTileButton();
            this.btnCostumer = new Bunifu.Framework.UI.BunifuTileButton();
            this.btnReport = new Bunifu.Framework.UI.BunifuTileButton();
            this.btnPos = new Bunifu.Framework.UI.BunifuTileButton();
            this.btnMenu1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pnlhi.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.formSkin1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 50;
            this.bunifuElipse1.TargetControl = this;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pnlhi
            // 
            this.pnlhi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(58)))), ((int)(((byte)(60)))));
            this.pnlhi.Controls.Add(this.btnProduct);
            this.pnlhi.Controls.Add(this.btnStaff);
            this.pnlhi.Controls.Add(this.btnCostumer);
            this.pnlhi.Controls.Add(this.btnReport);
            this.pnlhi.Controls.Add(this.btnPos);
            this.pnlhi.Controls.Add(this.btnMenu1);
            this.pnlhi.Location = new System.Drawing.Point(0, 50);
            this.pnlhi.Name = "pnlhi";
            this.pnlhi.Size = new System.Drawing.Size(200, 606);
            this.pnlhi.TabIndex = 0;
            // 
            // cbTime
            // 
            this.cbTime.BackColor = System.Drawing.Color.Transparent;
            this.cbTime.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbTime.ForeColor = System.Drawing.Color.White;
            this.cbTime.Location = new System.Drawing.Point(77, 16);
            this.cbTime.Name = "cbTime";
            this.cbTime.Size = new System.Drawing.Size(109, 29);
            this.cbTime.TabIndex = 14;
            this.cbTime.Text = "12:00";
            this.cbTime.Click += new System.EventHandler(this.cbTime_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sETTINGSToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(749, 15);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.menuStrip1.Size = new System.Drawing.Size(171, 24);
            this.menuStrip1.TabIndex = 17;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // sETTINGSToolStripMenuItem
            // 
            this.sETTINGSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnSession,
            this.btnUser,
            this.databaseConfigurationToolStripMenuItem,
            this.printSaleReportToolStripMenuItem});
            this.sETTINGSToolStripMenuItem.Name = "sETTINGSToolStripMenuItem";
            this.sETTINGSToolStripMenuItem.Size = new System.Drawing.Size(163, 20);
            this.sETTINGSToolStripMenuItem.Text = "Point of Sale Maintainance ";
            this.sETTINGSToolStripMenuItem.Click += new System.EventHandler(this.sETTINGSToolStripMenuItem_Click);
            // 
            // btnSession
            // 
            this.btnSession.Name = "btnSession";
            this.btnSession.Size = new System.Drawing.Size(199, 22);
            this.btnSession.Text = "Session History";
            this.btnSession.Click += new System.EventHandler(this.loginLogoutHistoryToolStripMenuItem_Click);
            // 
            // btnUser
            // 
            this.btnUser.Name = "btnUser";
            this.btnUser.Size = new System.Drawing.Size(199, 22);
            this.btnUser.Text = "Change User";
            this.btnUser.Click += new System.EventHandler(this.btnUser_Click);
            // 
            // databaseConfigurationToolStripMenuItem
            // 
            this.databaseConfigurationToolStripMenuItem.Name = "databaseConfigurationToolStripMenuItem";
            this.databaseConfigurationToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.databaseConfigurationToolStripMenuItem.Text = "Database Configuration";
            this.databaseConfigurationToolStripMenuItem.Click += new System.EventHandler(this.databaseConfigurationToolStripMenuItem_Click);
            // 
            // printSaleReportToolStripMenuItem
            // 
            this.printSaleReportToolStripMenuItem.Name = "printSaleReportToolStripMenuItem";
            this.printSaleReportToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.printSaleReportToolStripMenuItem.Text = "Print Sale Report";
            this.printSaleReportToolStripMenuItem.Click += new System.EventHandler(this.printSaleReportToolStripMenuItem_Click);
            // 
            // flatMini3
            // 
            this.flatMini3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.flatMini3.BackColor = System.Drawing.Color.White;
            this.flatMini3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.flatMini3.Font = new System.Drawing.Font("Marlett", 12F);
            this.flatMini3.Location = new System.Drawing.Point(1092, 15);
            this.flatMini3.Name = "flatMini3";
            this.flatMini3.Size = new System.Drawing.Size(18, 18);
            this.flatMini3.TabIndex = 21;
            this.flatMini3.Text = "flatMini1";
            this.flatMini3.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI Light", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(430, 16);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(288, 20);
            this.lblTitle.TabIndex = 5;
            this.lblTitle.Text = "YOUR PRODUCT DESERVED TO BE THE BEST";
            // 
            // formSkin1
            // 
            this.formSkin1.BackColor = System.Drawing.Color.White;
            this.formSkin1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.formSkin1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(58)))), ((int)(((byte)(60)))));
            this.formSkin1.Controls.Add(this.panel1);
            this.formSkin1.Controls.Add(this.MainPanel);
            this.formSkin1.Controls.Add(this.pnlhi);
            this.formSkin1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.formSkin1.FlatColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(168)))), ((int)(((byte)(109)))));
            this.formSkin1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.formSkin1.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.formSkin1.HeaderMaximize = false;
            this.formSkin1.Location = new System.Drawing.Point(0, 0);
            this.formSkin1.Name = "formSkin1";
            this.formSkin1.Size = new System.Drawing.Size(1150, 656);
            this.formSkin1.TabIndex = 0;
            this.formSkin1.Click += new System.EventHandler(this.formSkin1_Load);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.panel1.Controls.Add(this.flatClose1);
            this.panel1.Controls.Add(this.lblDateTime);
            this.panel1.Controls.Add(this.lbluser);
            this.panel1.Controls.Add(this.lblTitle);
            this.panel1.Controls.Add(this.menuStrip1);
            this.panel1.Controls.Add(this.flatMini3);
            this.panel1.Controls.Add(this.button10);
            this.panel1.Controls.Add(this.bunifuImageButton1);
            this.panel1.Controls.Add(this.cbTime);
            this.panel1.Location = new System.Drawing.Point(-2, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1151, 50);
            this.panel1.TabIndex = 23;
            // 
            // flatClose1
            // 
            this.flatClose1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.flatClose1.BackColor = System.Drawing.Color.White;
            this.flatClose1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.flatClose1.Font = new System.Drawing.Font("Marlett", 10F);
            this.flatClose1.Location = new System.Drawing.Point(1117, 14);
            this.flatClose1.Name = "flatClose1";
            this.flatClose1.Size = new System.Drawing.Size(18, 18);
            this.flatClose1.TabIndex = 24;
            this.flatClose1.Text = "flatClose1";
            this.flatClose1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.flatClose1.Click += new System.EventHandler(this.flatClose1_Click);
            // 
            // lblDateTime
            // 
            this.lblDateTime.BackColor = System.Drawing.Color.Transparent;
            this.lblDateTime.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateTime.ForeColor = System.Drawing.Color.White;
            this.lblDateTime.Location = new System.Drawing.Point(199, 14);
            this.lblDateTime.Name = "lblDateTime";
            this.lblDateTime.Size = new System.Drawing.Size(230, 29);
            this.lblDateTime.TabIndex = 23;
            this.lblDateTime.Click += new System.EventHandler(this.lblDateTime_Click);
            // 
            // lbluser
            // 
            this.lbluser.BackColor = System.Drawing.Color.Transparent;
            this.lbluser.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbluser.ForeColor = System.Drawing.Color.Yellow;
            this.lbluser.Location = new System.Drawing.Point(929, 12);
            this.lbluser.Name = "lbluser";
            this.lbluser.Size = new System.Drawing.Size(140, 29);
            this.lbluser.TabIndex = 9;
            this.lbluser.Text = "   Login user : ADMIN";
            this.lbluser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbluser.Click += new System.EventHandler(this.lbluser_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Transparent;
            this.button10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button10.BackgroundImage")));
            this.button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button10.Enabled = false;
            this.button10.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(11, 5);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(60, 42);
            this.button10.TabIndex = 13;
            this.button10.UseVisualStyleBackColor = false;
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.ErrorImage")));
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.InitialImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.InitialImage")));
            this.bunifuImageButton1.Location = new System.Drawing.Point(1069, 16);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(17, 18);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 20;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            this.bunifuImageButton1.Click += new System.EventHandler(this.bunifuImageButton1_Click);
            // 
            // MainPanel
            // 
            this.MainPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.MainPanel.BackgroundImage = global::FinalDeisgn.Properties.Resources.logo1;
            this.MainPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.MainPanel.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainPanel.Location = new System.Drawing.Point(200, 49);
            this.MainPanel.Name = "MainPanel";
            this.MainPanel.Size = new System.Drawing.Size(947, 606);
            this.MainPanel.TabIndex = 1;
            this.MainPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.MainPanel_Paint);
            // 
            // btnProduct
            // 
            this.btnProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.btnProduct.color = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.btnProduct.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.btnProduct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProduct.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProduct.ForeColor = System.Drawing.Color.White;
            this.btnProduct.Image = ((System.Drawing.Image)(resources.GetObject("btnProduct.Image")));
            this.btnProduct.ImagePosition = 30;
            this.btnProduct.ImageZoom = 20;
            this.btnProduct.LabelPosition = 28;
            this.btnProduct.LabelText = "Products";
            this.btnProduct.Location = new System.Drawing.Point(-2, 488);
            this.btnProduct.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnProduct.Name = "btnProduct";
            this.btnProduct.Size = new System.Drawing.Size(204, 118);
            this.btnProduct.TabIndex = 6;
            this.btnProduct.Click += new System.EventHandler(this.bunifuTileButton4_Click);
            // 
            // btnStaff
            // 
            this.btnStaff.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.btnStaff.color = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.btnStaff.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.btnStaff.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStaff.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStaff.ForeColor = System.Drawing.Color.White;
            this.btnStaff.Image = ((System.Drawing.Image)(resources.GetObject("btnStaff.Image")));
            this.btnStaff.ImagePosition = 30;
            this.btnStaff.ImageZoom = 20;
            this.btnStaff.LabelPosition = 28;
            this.btnStaff.LabelText = "Staff";
            this.btnStaff.Location = new System.Drawing.Point(0, 366);
            this.btnStaff.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnStaff.Name = "btnStaff";
            this.btnStaff.Size = new System.Drawing.Size(202, 121);
            this.btnStaff.TabIndex = 5;
            this.btnStaff.Click += new System.EventHandler(this.bunifuTileButton5_Click);
            // 
            // btnCostumer
            // 
            this.btnCostumer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.btnCostumer.color = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.btnCostumer.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.btnCostumer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCostumer.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCostumer.ForeColor = System.Drawing.Color.White;
            this.btnCostumer.Image = ((System.Drawing.Image)(resources.GetObject("btnCostumer.Image")));
            this.btnCostumer.ImagePosition = 30;
            this.btnCostumer.ImageZoom = 20;
            this.btnCostumer.LabelPosition = 28;
            this.btnCostumer.LabelText = "Costumer Service";
            this.btnCostumer.Location = new System.Drawing.Point(-2, 243);
            this.btnCostumer.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCostumer.Name = "btnCostumer";
            this.btnCostumer.Size = new System.Drawing.Size(202, 122);
            this.btnCostumer.TabIndex = 4;
            this.btnCostumer.Click += new System.EventHandler(this.bunifuTileButton3_Click);
            // 
            // btnReport
            // 
            this.btnReport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.btnReport.color = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.btnReport.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.btnReport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReport.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport.ForeColor = System.Drawing.Color.White;
            this.btnReport.Image = ((System.Drawing.Image)(resources.GetObject("btnReport.Image")));
            this.btnReport.ImagePosition = 30;
            this.btnReport.ImageZoom = 20;
            this.btnReport.LabelPosition = 28;
            this.btnReport.LabelText = "Sale Reports";
            this.btnReport.Location = new System.Drawing.Point(-2, 116);
            this.btnReport.Margin = new System.Windows.Forms.Padding(6);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(204, 126);
            this.btnReport.TabIndex = 3;
            this.btnReport.Click += new System.EventHandler(this.bunifuTileButton2_Click);
            // 
            // btnPos
            // 
            this.btnPos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.btnPos.color = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.btnPos.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.btnPos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPos.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPos.ForeColor = System.Drawing.Color.White;
            this.btnPos.Image = ((System.Drawing.Image)(resources.GetObject("btnPos.Image")));
            this.btnPos.ImagePosition = 30;
            this.btnPos.ImageZoom = 20;
            this.btnPos.LabelPosition = 28;
            this.btnPos.LabelText = "POS";
            this.btnPos.Location = new System.Drawing.Point(-2, -4);
            this.btnPos.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPos.Name = "btnPos";
            this.btnPos.Size = new System.Drawing.Size(202, 119);
            this.btnPos.TabIndex = 2;
            this.btnPos.Click += new System.EventHandler(this.bunifuTileButton1_Click);
            // 
            // btnMenu1
            // 
            this.btnMenu1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(168)))), ((int)(((byte)(109)))));
            this.btnMenu1.BackColor = System.Drawing.Color.Transparent;
            this.btnMenu1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMenu1.BackgroundImage")));
            this.btnMenu1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMenu1.BorderRadius = 7;
            this.btnMenu1.ButtonText = "";
            this.btnMenu1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMenu1.DisabledColor = System.Drawing.Color.Gray;
            this.btnMenu1.Iconcolor = System.Drawing.Color.Transparent;
            this.btnMenu1.Iconimage = null;
            this.btnMenu1.Iconimage_right = null;
            this.btnMenu1.Iconimage_right_Selected = null;
            this.btnMenu1.Iconimage_Selected = null;
            this.btnMenu1.IconMarginLeft = 0;
            this.btnMenu1.IconMarginRight = 0;
            this.btnMenu1.IconRightVisible = true;
            this.btnMenu1.IconRightZoom = 0D;
            this.btnMenu1.IconVisible = true;
            this.btnMenu1.IconZoom = 90D;
            this.btnMenu1.IsTab = false;
            this.btnMenu1.Location = new System.Drawing.Point(228, 8);
            this.btnMenu1.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.btnMenu1.Name = "btnMenu1";
            this.btnMenu1.Normalcolor = System.Drawing.Color.Transparent;
            this.btnMenu1.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnMenu1.OnHoverTextColor = System.Drawing.Color.White;
            this.btnMenu1.selected = false;
            this.btnMenu1.Size = new System.Drawing.Size(66, 55);
            this.btnMenu1.TabIndex = 1;
            this.btnMenu1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenu1.Textcolor = System.Drawing.Color.White;
            this.btnMenu1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenu1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1150, 656);
            this.Controls.Add(this.formSkin1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.TransparencyKey = System.Drawing.Color.Fuchsia;
            this.Load += new System.EventHandler(this.Form1_Load_3);
            this.pnlhi.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.formSkin1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Timer timer1;
        private FlatUI.FormSkin formSkin1;
        private System.Windows.Forms.Label lblTitle;
        private FlatUI.FlatMini flatMini3;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem sETTINGSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem btnSession;
        private System.Windows.Forms.ToolStripMenuItem btnUser;
        private System.Windows.Forms.ToolStripMenuItem databaseConfigurationToolStripMenuItem;
        private System.Windows.Forms.Label cbTime;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Panel MainPanel;
        private System.Windows.Forms.Panel pnlhi;
        private Bunifu.Framework.UI.BunifuTileButton btnProduct;
        private Bunifu.Framework.UI.BunifuTileButton btnStaff;
        private Bunifu.Framework.UI.BunifuTileButton btnCostumer;
        private Bunifu.Framework.UI.BunifuTileButton btnReport;
        private Bunifu.Framework.UI.BunifuTileButton btnPos;
        private Bunifu.Framework.UI.BunifuFlatButton btnMenu1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblDateTime;
        private System.Windows.Forms.ToolStripMenuItem printSaleReportToolStripMenuItem;
        private System.Windows.Forms.Label lbluser;
        private FlatUI.FlatClose flatClose1;

    }
}

