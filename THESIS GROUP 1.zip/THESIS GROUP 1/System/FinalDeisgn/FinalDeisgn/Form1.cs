﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Threading;
namespace FinalDeisgn
{
    public partial class Form1 : Form
    {

        MySqlConnection con = new MySqlConnection(@"Data Source=localhost;port=3306;Initial Catalog=dbstaff;User Id=root;password=''");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataReader dr;
        public string user;
        public string role1;
        private string p;
        private int p_2;

        public Form1(string role)
        {
            InitializeComponent();
            getRole(role);
        }

        public Form1(string p, int p_2)
        {
            // TODO: Complete member initialization
            this.p = p;
            this.p_2 = p_2;
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        { 
        

        }


        public void getRole(string role)
        {

            role1 = role;



        }

        private void formSkin1_Click(object sender, EventArgs e)
        {


        }
             private void Form1_Load(object sender, EventArgs e)
        {

           
        }

        private void btnMenu2_Click_1(object sender, EventArgs e)
        {

        }

        private void bunifuTileButton1_Click(object sender, EventArgs e)
        {
            MainPanel.Controls.Clear();
            Pos rep = new Pos();
            rep.TopLevel = false;
            MainPanel.Controls.Add(rep);
            rep.Show();


            string action = "POS";
            Main code = new Main();
            code.Execute(@"INSERT INTO tblsession values  ('" + Login.Username + "','" + Login.ID + "','" + action + "','" + DateTime.Now + "')");

           



          
        }

        private void bunifuTileButton2_Click(object sender, EventArgs e)
        {

            MainPanel.Controls.Clear();
            Reports rep = new Reports();
            rep.TopLevel = false;
            MainPanel.Controls.Add(rep);
            rep.Show();



            string action = "Sale Reports";
            Main code = new Main();
            code.Execute(@"INSERT INTO tblsession values  ('" + Login.Username + "','" + Login.ID + "','" + action + "','" + DateTime.Now + "')");

           


        }

        private void bunifuTileButton3_Click(object sender, EventArgs e)
        {
            MainPanel.Controls.Clear();
            CostumerService rep = new CostumerService();
            rep.TopLevel = false;
            MainPanel.Controls.Add(rep);
            rep.Show();


            string action = "Customer Service";
            Main code = new Main();
            code.Execute(@"INSERT INTO tblsession values  ('" + lbluser + "','" + Login.ID + "','" + action + "','" + DateTime.Now + "')");

           


        }

        private void bunifuTileButton5_Click(object sender, EventArgs e)
        {
            MainPanel.Controls.Clear();
            Staff st = new Staff(role1);
            st.TopLevel = false;
            MainPanel.Controls.Add(st);
            st.Show();


            string action = "Staff";
            Main code = new Main();
            code.Execute(@"INSERT INTO tblsession values  ('" + lbluser + "','" + Login.ID + "','" + action + "','" + DateTime.Now + "')");

           

        }

        private void bunifuTileButton4_Click(object sender, EventArgs e)
        {
            MainPanel.Controls.Clear();
            Product st = new Product();
            st.TopLevel = false;
            MainPanel.Controls.Add(st);
            st.Show();


            string action = "Product";
            Main code = new Main();
            code.Execute(@"INSERT INTO tblsession values  ('" + lbluser + "','" + Login.ID + "','" + action + "','" + DateTime.Now + "')");

           

        }

        private void flatClose3_Click(object sender, EventArgs e)
        {
            //DialogResult dialog = MessageBox.Show("Are you sure to exit ?","LOGOUT", MessageBoxButtons.YesNo);
            //if (dialog == DialogResult.Yes)
            //{
            //    con.Open();
            //    cmd = new MySqlCommand("INSERT INTO `tblhistory`(`TimeLogOut`) values ('" +cbTime.Text+"')", con);
            //    cmd.ExecuteNonQuery();
            //    con.Close();
            //    Application.Exit();
            //}
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            Form1 dr = new Form1(role1);
            dr.Show();
            this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            cbTime.Text = DateTime.Now.ToString("hh:mm tt");
            lblDateTime.Text = "Date : " + DateTime.Now.ToString("MMMM dd, yyyy");
        }

        private void loginLogoutHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainPanel.Controls.Clear();
           Session rep = new Session();
            rep.TopLevel = false;
            MainPanel.Controls.Add(rep);
            rep.Show();
            //string action = "Session History";
            //Main code = new Main();
            //code.Execute(@"INSERT INTO tblsession values  ('" + lbluser.Text + "','" + Login.ID + "','" + action + "','" + DateTime.Now + "')");

           
        }

        private void sETTINGSToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void databaseConfigurationToolStripMenuItem_Click(object sender, EventArgs e)
        {
              DialogResult dialog = MessageBox.Show("Are you sure to configurate you database  ?", "It result to a server maintainance and if there problem you may contact your administrator or you maintainance technician", MessageBoxButtons.YesNo);
              if (dialog == DialogResult.Yes)
              {
                  MainPanel.Controls.Clear();
                  frmDatabaseConfig rep = new frmDatabaseConfig();
                  rep.TopLevel = false;
                  MainPanel.Controls.Add(rep);
                  rep.Show();
              }
              string action = "Database Configuration";
              Main code = new Main();
              code.Execute(@"INSERT INTO tblsession values  ('" + Login.Username + "','" + Login.ID + "','" + action + "','" + DateTime.Now + "')");

           
        }
        private void ol() {

            string action = "Change User";
            Main code = new Main();
            code.Execute(@"INSERT INTO tblsession values  ('" + Login.Username + "','" + Login.ID + "','" + action + "','" + DateTime.Now + "')");
        
        }

        private void btnUser_Click(object sender, EventArgs e)
        {
            ol();
            Login lg = new Login();
            lg.Show();
            this.Hide();
            

           
           
        }

        private void formSkin1_Load(object sender, EventArgs e)
        {
            timer1.Start();
            if (role1 == "Cashier")
            {



                btnReport.Enabled = false;
                btnStaff.Enabled = false;
                btnProduct.Enabled = false;
                btnSession.Enabled = false;
                databaseConfigurationToolStripMenuItem.Enabled = false;


            }
            else
            {


                btnReport.Enabled = true;
                btnStaff.Enabled = true;
                btnProduct.Enabled = true;
                btnSession.Enabled = true;
                databaseConfigurationToolStripMenuItem.Enabled = true;

            }
        }
             private void Form1_Load_1(object sender, EventArgs e)
        {
                timer1.Start();
            if (role1 == "Cashier")
            {



                btnReport.Enabled = false;
                btnStaff.Enabled = false;
                btnProduct.Enabled = false;
                btnSession.Enabled = false;
                databaseConfigurationToolStripMenuItem.Enabled = false;


            }
            else
            {


                btnReport.Enabled = true;
                btnStaff.Enabled = true;
                btnProduct.Enabled = true;
                btnSession.Enabled = true;
                databaseConfigurationToolStripMenuItem.Enabled = true;

            }
        }

             private void Form1_Load_2(object sender, EventArgs e)
             {
                 timer1.Start();
                 if (role1 == "Cashier")
                 {



                     btnReport.Enabled = false;
                     btnStaff.Enabled = false;
                     btnProduct.Enabled = false;
                     btnSession.Enabled = false;
                     databaseConfigurationToolStripMenuItem.Enabled = false;


                 }
                 else
                 {



                     btnReport.Enabled = true;
                     btnStaff.Enabled = true;
                     btnProduct.Enabled = true;
                     btnSession.Enabled = true;
                     databaseConfigurationToolStripMenuItem.Enabled = true;

                 }
             }

             private void Form1_Load_3(object sender, EventArgs e)
             {
                 timer1.Start();
                 if (role1 == "Cashier")
                 {



                   
                     btnStaff.Enabled = false;
                     btnReport.Enabled = false;
                     btnProduct.Enabled = false;
                     btnSession.Enabled = false;
                     databaseConfigurationToolStripMenuItem.Enabled = false;


                 }
                 else
                 {



                     btnReport.Enabled = true;
                     btnStaff.Enabled = true;
                     btnProduct.Enabled = true;
                     btnSession.Enabled = true;
                     databaseConfigurationToolStripMenuItem.Enabled = true;

                 }
                
                 this.lbluser.Text = "Login user : " + role1;

             }

             private void MainPanel_Paint(object sender, PaintEventArgs e)
             {

             }

             private void cbTime_Click(object sender, EventArgs e)
             {

             }

             private void printSaleReportToolStripMenuItem_Click(object sender, EventArgs e)
             {
               
                 
                 Print lg = new Print();
                 lg.Show();
                 string action = "Print Sale Report";
                 Main code = new Main();
                 code.Execute(@"INSERT INTO tblsession values  ('" + Login.Username + "','" + Login.ID + "','" + action + "','" + DateTime.Now + "')");

           


             }

             private void lblDateTime_Click(object sender, EventArgs e)
             {

             }

             private void flatClose1_Click(object sender, EventArgs e)
             {

             }

             private void wewToolStripMenuItem_Click(object sender, EventArgs e)
             {
                 //this.Close();
                 //string action = "Log Out";
                 //Main code = new Main();
                 //code.Execute(@"INSERT INTO tblsession values  ('" + Login.Username + "','" + Login.ID + "','" + action + "','" + DateTime.Now + "')");
             }

             private void lbluser_Click(object sender, EventArgs e)
             {

             }

        }
    }
