﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using MySql.Data.MySqlClient;


namespace FinalDeisgn
{
    public partial class Sample2 : Form
    {
        MySqlConnection con = new MySqlConnection(@"Data Source=localhost;port=3306;Initial Catalog=dbstaff;User Id=root;password=''");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataReader dr;

        public Sample2()
        {
            InitializeComponent();
        }

        public void GenerateReport(string d1, string d2)
        {
            dsReportC ds = new dsReportC();
            MySqlDataAdapter da = new MySqlDataAdapter();
            con.Open();
            da.SelectCommand = new MySqlCommand("Select * from tblmain where DateSold between '" + d1 + "' and '" + d2 + "'", con);
            da.Fill(ds, "DataTable3");
            Hays sample = new Hays();
            sample.Load(Application.StartupPath + @"\Hays.rpt");
            sample.SetDataSource(ds.Tables["DataTable3"]);
            crystalReportViewer1.ReportSource = sample;
            crystalReportViewer1.Refresh();
            con.Close();
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {

        }
        
    }
}
