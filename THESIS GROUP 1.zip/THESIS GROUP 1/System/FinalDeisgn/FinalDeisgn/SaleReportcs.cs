﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using MySql.Data.MySqlClient;

namespace FinalDeisgn
{
    public partial class SaleReportcs : Form
    {

        MySqlConnection con = new MySqlConnection(@"Data Source=localhost;port=3306;Initial Catalog=dbstaff;User Id=root;password=''");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataReader dr;
        public SaleReportcs()
        {
            InitializeComponent();
        }

        private void SaleReportcs_Load(object sender, EventArgs e)
        {

            //this.reportViewer1.RefreshReport();

        }

        private void flatClose1_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        public void GenerateReport(string d1, string d2)
        {
            dsReportC ds = new dsReportC();
            MySqlDataAdapter da = new MySqlDataAdapter();
            con.Open();
        //    da.SelectCommand = new MySqlCommand("Select * from tblmain where DateSold between '" + d1 + "' and '" + d2 + "'", con);
            da.SelectCommand = new MySqlCommand("Select * from tblmain",con); // where DateSold between '" + d1 + "' and '" + d2 + "'", con);
      
            da.Fill(ds, "DataTable3");
            SoldReport sample = new SoldReport();
            sample.Load(Application.StartupPath + @"\SoldReport.rpt");
            sample.SetDataSource(ds.Tables["DataTable3"]);
            crystalReportViewer1.ReportSource = sample;
           // crystalReportViewer1.Refresh();
            con.Close();
        }


        private void crystalReportViewer2_Load(object sender, EventArgs e)
        {
            //GenerateReport();
        }

        private void crystalReportViewer2_Load_1(object sender, EventArgs e)
        {

        }
    }
}
