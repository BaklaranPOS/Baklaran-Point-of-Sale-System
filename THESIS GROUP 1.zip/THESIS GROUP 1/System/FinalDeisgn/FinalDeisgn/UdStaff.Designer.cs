﻿namespace FinalDeisgn
{
    partial class UdStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblID = new System.Windows.Forms.Label();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.cbRole = new FlatUI.FlatComboBox();
            this.txtConfirmPs = new FlatUI.FlatTextBox();
            this.txtPassword = new FlatUI.FlatTextBox();
            this.txtUsername = new FlatUI.FlatTextBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.flatLabel8 = new FlatUI.FlatLabel();
            this.flatLabel7 = new FlatUI.FlatLabel();
            this.flatLabel6 = new FlatUI.FlatLabel();
            this.flatLabel5 = new FlatUI.FlatLabel();
            this.flatLabel4 = new FlatUI.FlatLabel();
            this.flatLabel3 = new FlatUI.FlatLabel();
            this.flatLabel1 = new FlatUI.FlatLabel();
            this.flatLabel2 = new FlatUI.FlatLabel();
            this.txtCity = new FlatUI.FlatTextBox();
            this.txtMI = new FlatUI.FlatTextBox();
            this.txtBarangay = new FlatUI.FlatTextBox();
            this.txtFirstname = new FlatUI.FlatTextBox();
            this.txtContractNo = new FlatUI.FlatTextBox();
            this.txtProvince = new FlatUI.FlatTextBox();
            this.txtStreet = new FlatUI.FlatTextBox();
            this.txtLastname = new FlatUI.FlatTextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.flatButton1 = new FlatUI.FlatButton();
            this.pbImage = new System.Windows.Forms.PictureBox();
            this.GroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).BeginInit();
            this.SuspendLayout();
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(582, 143);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(35, 13);
            this.lblID.TabIndex = 158;
            this.lblID.Text = "label1";
            this.lblID.Visible = false;
            // 
            // dtpDate
            // 
            this.dtpDate.Location = new System.Drawing.Point(431, 259);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(197, 20);
            this.dtpDate.TabIndex = 157;
            this.dtpDate.Visible = false;
            // 
            // GroupBox3
            // 
            this.GroupBox3.BackColor = System.Drawing.Color.Transparent;
            this.GroupBox3.Controls.Add(this.cbRole);
            this.GroupBox3.Controls.Add(this.txtConfirmPs);
            this.GroupBox3.Controls.Add(this.txtPassword);
            this.GroupBox3.Controls.Add(this.txtUsername);
            this.GroupBox3.Controls.Add(this.lbl1);
            this.GroupBox3.Controls.Add(this.label6);
            this.GroupBox3.Controls.Add(this.Label9);
            this.GroupBox3.Controls.Add(this.Label7);
            this.GroupBox3.Controls.Add(this.Label8);
            this.GroupBox3.Controls.Add(this.Label5);
            this.GroupBox3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.GroupBox3.Location = new System.Drawing.Point(19, 298);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(621, 117);
            this.GroupBox3.TabIndex = 156;
            this.GroupBox3.TabStop = false;
            this.GroupBox3.Text = "User Information";
            // 
            // cbRole
            // 
            this.cbRole.BackColor = System.Drawing.Color.White;
            this.cbRole.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cbRole.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbRole.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.cbRole.ForeColor = System.Drawing.Color.Yellow;
            this.cbRole.FormattingEnabled = true;
            this.cbRole.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(168)))), ((int)(((byte)(109)))));
            this.cbRole.ItemHeight = 18;
            this.cbRole.Items.AddRange(new object[] {
            "Admin",
            "Cashier"});
            this.cbRole.Location = new System.Drawing.Point(98, 71);
            this.cbRole.Name = "cbRole";
            this.cbRole.Size = new System.Drawing.Size(173, 24);
            this.cbRole.TabIndex = 94;
            // 
            // txtConfirmPs
            // 
            this.txtConfirmPs.BackColor = System.Drawing.Color.White;
            this.txtConfirmPs.FocusOnHover = false;
            this.txtConfirmPs.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConfirmPs.Location = new System.Drawing.Point(429, 71);
            this.txtConfirmPs.MaxLength = 32767;
            this.txtConfirmPs.Multiline = false;
            this.txtConfirmPs.Name = "txtConfirmPs";
            this.txtConfirmPs.ReadOnly = false;
            this.txtConfirmPs.Size = new System.Drawing.Size(170, 29);
            this.txtConfirmPs.TabIndex = 93;
            this.txtConfirmPs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtConfirmPs.TextColor = System.Drawing.Color.Yellow;
            this.txtConfirmPs.UseSystemPasswordChar = true;
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.Color.White;
            this.txtPassword.FocusOnHover = false;
            this.txtPassword.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(429, 34);
            this.txtPassword.MaxLength = 32767;
            this.txtPassword.Multiline = false;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.ReadOnly = false;
            this.txtPassword.Size = new System.Drawing.Size(170, 29);
            this.txtPassword.TabIndex = 92;
            this.txtPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtPassword.TextColor = System.Drawing.Color.Yellow;
            this.txtPassword.UseSystemPasswordChar = true;
            // 
            // txtUsername
            // 
            this.txtUsername.BackColor = System.Drawing.Color.White;
            this.txtUsername.FocusOnHover = false;
            this.txtUsername.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsername.Location = new System.Drawing.Point(98, 31);
            this.txtUsername.MaxLength = 32767;
            this.txtUsername.Multiline = false;
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.ReadOnly = false;
            this.txtUsername.Size = new System.Drawing.Size(173, 29);
            this.txtUsername.TabIndex = 90;
            this.txtUsername.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtUsername.TextColor = System.Drawing.Color.Yellow;
            this.txtUsername.UseSystemPasswordChar = false;
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Verdana", 3.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(456, 86);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(5, 6);
            this.lbl1.TabIndex = 14;
            this.lbl1.Text = ".";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(616, 63);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 12);
            this.label6.TabIndex = 13;
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.ForeColor = System.Drawing.Color.White;
            this.Label9.Location = new System.Drawing.Point(288, 76);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(135, 16);
            this.Label9.TabIndex = 12;
            this.Label9.Text = "Confirm Password :";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.ForeColor = System.Drawing.Color.White;
            this.Label7.Location = new System.Drawing.Point(46, 76);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(46, 16);
            this.Label7.TabIndex = 11;
            this.Label7.Text = "Role :";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.ForeColor = System.Drawing.Color.White;
            this.Label8.Location = new System.Drawing.Point(342, 37);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(81, 16);
            this.Label8.TabIndex = 9;
            this.Label8.Text = "Password :";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.ForeColor = System.Drawing.Color.White;
            this.Label5.Location = new System.Drawing.Point(9, 34);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(83, 16);
            this.Label5.TabIndex = 8;
            this.Label5.Text = "Username :";
            // 
            // flatLabel8
            // 
            this.flatLabel8.AutoSize = true;
            this.flatLabel8.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel8.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.flatLabel8.ForeColor = System.Drawing.Color.White;
            this.flatLabel8.Location = new System.Drawing.Point(233, 243);
            this.flatLabel8.Name = "flatLabel8";
            this.flatLabel8.Size = new System.Drawing.Size(68, 13);
            this.flatLabel8.TabIndex = 155;
            this.flatLabel8.Text = "Contact No.";
            // 
            // flatLabel7
            // 
            this.flatLabel7.AutoSize = true;
            this.flatLabel7.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel7.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.flatLabel7.ForeColor = System.Drawing.Color.White;
            this.flatLabel7.Location = new System.Drawing.Point(36, 243);
            this.flatLabel7.Name = "flatLabel7";
            this.flatLabel7.Size = new System.Drawing.Size(50, 13);
            this.flatLabel7.TabIndex = 154;
            this.flatLabel7.Text = "Province";
            // 
            // flatLabel6
            // 
            this.flatLabel6.AutoSize = true;
            this.flatLabel6.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel6.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.flatLabel6.ForeColor = System.Drawing.Color.White;
            this.flatLabel6.Location = new System.Drawing.Point(428, 198);
            this.flatLabel6.Name = "flatLabel6";
            this.flatLabel6.Size = new System.Drawing.Size(26, 13);
            this.flatLabel6.TabIndex = 153;
            this.flatLabel6.Text = "City";
            // 
            // flatLabel5
            // 
            this.flatLabel5.AutoSize = true;
            this.flatLabel5.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel5.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.flatLabel5.ForeColor = System.Drawing.Color.White;
            this.flatLabel5.Location = new System.Drawing.Point(233, 198);
            this.flatLabel5.Name = "flatLabel5";
            this.flatLabel5.Size = new System.Drawing.Size(55, 13);
            this.flatLabel5.TabIndex = 152;
            this.flatLabel5.Text = "Barangay";
            // 
            // flatLabel4
            // 
            this.flatLabel4.AutoSize = true;
            this.flatLabel4.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel4.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.flatLabel4.ForeColor = System.Drawing.Color.White;
            this.flatLabel4.Location = new System.Drawing.Point(36, 195);
            this.flatLabel4.Name = "flatLabel4";
            this.flatLabel4.Size = new System.Drawing.Size(37, 13);
            this.flatLabel4.TabIndex = 151;
            this.flatLabel4.Text = "Street";
            // 
            // flatLabel3
            // 
            this.flatLabel3.AutoSize = true;
            this.flatLabel3.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel3.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.flatLabel3.ForeColor = System.Drawing.Color.White;
            this.flatLabel3.Location = new System.Drawing.Point(233, 150);
            this.flatLabel3.Name = "flatLabel3";
            this.flatLabel3.Size = new System.Drawing.Size(57, 13);
            this.flatLabel3.TabIndex = 150;
            this.flatLabel3.Text = "Firstname";
            // 
            // flatLabel1
            // 
            this.flatLabel1.AutoSize = true;
            this.flatLabel1.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel1.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.flatLabel1.ForeColor = System.Drawing.Color.White;
            this.flatLabel1.Location = new System.Drawing.Point(428, 150);
            this.flatLabel1.Name = "flatLabel1";
            this.flatLabel1.Size = new System.Drawing.Size(75, 13);
            this.flatLabel1.TabIndex = 149;
            this.flatLabel1.Text = "Middle Initial";
            // 
            // flatLabel2
            // 
            this.flatLabel2.AutoSize = true;
            this.flatLabel2.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel2.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.flatLabel2.ForeColor = System.Drawing.Color.White;
            this.flatLabel2.Location = new System.Drawing.Point(36, 150);
            this.flatLabel2.Name = "flatLabel2";
            this.flatLabel2.Size = new System.Drawing.Size(55, 13);
            this.flatLabel2.TabIndex = 148;
            this.flatLabel2.Text = "Lastname";
            // 
            // txtCity
            // 
            this.txtCity.BackColor = System.Drawing.Color.Transparent;
            this.txtCity.FocusOnHover = false;
            this.txtCity.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCity.Location = new System.Drawing.Point(431, 211);
            this.txtCity.MaxLength = 32767;
            this.txtCity.Multiline = false;
            this.txtCity.Name = "txtCity";
            this.txtCity.ReadOnly = false;
            this.txtCity.Size = new System.Drawing.Size(197, 29);
            this.txtCity.TabIndex = 147;
            this.txtCity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCity.TextColor = System.Drawing.Color.Yellow;
            this.txtCity.UseSystemPasswordChar = false;
            // 
            // txtMI
            // 
            this.txtMI.BackColor = System.Drawing.Color.Transparent;
            this.txtMI.FocusOnHover = false;
            this.txtMI.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMI.Location = new System.Drawing.Point(431, 166);
            this.txtMI.MaxLength = 32767;
            this.txtMI.Multiline = false;
            this.txtMI.Name = "txtMI";
            this.txtMI.ReadOnly = false;
            this.txtMI.Size = new System.Drawing.Size(197, 29);
            this.txtMI.TabIndex = 146;
            this.txtMI.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtMI.TextColor = System.Drawing.Color.Yellow;
            this.txtMI.UseSystemPasswordChar = false;
            // 
            // txtBarangay
            // 
            this.txtBarangay.BackColor = System.Drawing.Color.Transparent;
            this.txtBarangay.FocusOnHover = false;
            this.txtBarangay.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBarangay.Location = new System.Drawing.Point(236, 211);
            this.txtBarangay.MaxLength = 32767;
            this.txtBarangay.Multiline = false;
            this.txtBarangay.Name = "txtBarangay";
            this.txtBarangay.ReadOnly = false;
            this.txtBarangay.Size = new System.Drawing.Size(173, 29);
            this.txtBarangay.TabIndex = 145;
            this.txtBarangay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBarangay.TextColor = System.Drawing.Color.Yellow;
            this.txtBarangay.UseSystemPasswordChar = false;
            // 
            // txtFirstname
            // 
            this.txtFirstname.BackColor = System.Drawing.Color.Transparent;
            this.txtFirstname.FocusOnHover = false;
            this.txtFirstname.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFirstname.Location = new System.Drawing.Point(236, 166);
            this.txtFirstname.MaxLength = 32767;
            this.txtFirstname.Multiline = false;
            this.txtFirstname.Name = "txtFirstname";
            this.txtFirstname.ReadOnly = false;
            this.txtFirstname.Size = new System.Drawing.Size(173, 29);
            this.txtFirstname.TabIndex = 144;
            this.txtFirstname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtFirstname.TextColor = System.Drawing.Color.Yellow;
            this.txtFirstname.UseSystemPasswordChar = false;
            // 
            // txtContractNo
            // 
            this.txtContractNo.BackColor = System.Drawing.Color.Transparent;
            this.txtContractNo.FocusOnHover = false;
            this.txtContractNo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContractNo.Location = new System.Drawing.Point(236, 259);
            this.txtContractNo.MaxLength = 32767;
            this.txtContractNo.Multiline = false;
            this.txtContractNo.Name = "txtContractNo";
            this.txtContractNo.ReadOnly = false;
            this.txtContractNo.Size = new System.Drawing.Size(173, 29);
            this.txtContractNo.TabIndex = 143;
            this.txtContractNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtContractNo.TextColor = System.Drawing.Color.Yellow;
            this.txtContractNo.UseSystemPasswordChar = false;
            // 
            // txtProvince
            // 
            this.txtProvince.BackColor = System.Drawing.Color.Transparent;
            this.txtProvince.FocusOnHover = false;
            this.txtProvince.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProvince.Location = new System.Drawing.Point(39, 256);
            this.txtProvince.MaxLength = 32767;
            this.txtProvince.Multiline = false;
            this.txtProvince.Name = "txtProvince";
            this.txtProvince.ReadOnly = false;
            this.txtProvince.Size = new System.Drawing.Size(173, 29);
            this.txtProvince.TabIndex = 142;
            this.txtProvince.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtProvince.TextColor = System.Drawing.Color.Yellow;
            this.txtProvince.UseSystemPasswordChar = false;
            // 
            // txtStreet
            // 
            this.txtStreet.BackColor = System.Drawing.Color.Transparent;
            this.txtStreet.FocusOnHover = false;
            this.txtStreet.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStreet.Location = new System.Drawing.Point(39, 211);
            this.txtStreet.MaxLength = 32767;
            this.txtStreet.Multiline = false;
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.ReadOnly = false;
            this.txtStreet.Size = new System.Drawing.Size(173, 29);
            this.txtStreet.TabIndex = 141;
            this.txtStreet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtStreet.TextColor = System.Drawing.Color.Yellow;
            this.txtStreet.UseSystemPasswordChar = false;
            // 
            // txtLastname
            // 
            this.txtLastname.BackColor = System.Drawing.Color.Transparent;
            this.txtLastname.FocusOnHover = false;
            this.txtLastname.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLastname.Location = new System.Drawing.Point(39, 166);
            this.txtLastname.MaxLength = 32767;
            this.txtLastname.Multiline = false;
            this.txtLastname.Name = "txtLastname";
            this.txtLastname.ReadOnly = false;
            this.txtLastname.Size = new System.Drawing.Size(173, 29);
            this.txtLastname.TabIndex = 140;
            this.txtLastname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtLastname.TextColor = System.Drawing.Color.Yellow;
            this.txtLastname.UseSystemPasswordChar = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(623, 24);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(22, 23);
            this.button2.TabIndex = 159;
            this.button2.Text = "X";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // flatButton1
            // 
            this.flatButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.flatButton1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(168)))), ((int)(((byte)(109)))));
            this.flatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.flatButton1.Location = new System.Drawing.Point(170, 421);
            this.flatButton1.Name = "flatButton1";
            this.flatButton1.Rounded = false;
            this.flatButton1.Size = new System.Drawing.Size(106, 32);
            this.flatButton1.TabIndex = 160;
            this.flatButton1.Text = "LOGIN";
            this.flatButton1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.flatButton1.Click += new System.EventHandler(this.flatButton1_Click);
            // 
            // pbImage
            // 
            this.pbImage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.pbImage.Location = new System.Drawing.Point(263, 24);
            this.pbImage.Name = "pbImage";
            this.pbImage.Size = new System.Drawing.Size(135, 106);
            this.pbImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbImage.TabIndex = 161;
            this.pbImage.TabStop = false;
            // 
            // UdStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.ClientSize = new System.Drawing.Size(657, 477);
            this.Controls.Add(this.pbImage);
            this.Controls.Add(this.flatButton1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.dtpDate);
            this.Controls.Add(this.GroupBox3);
            this.Controls.Add(this.flatLabel8);
            this.Controls.Add(this.flatLabel7);
            this.Controls.Add(this.flatLabel6);
            this.Controls.Add(this.flatLabel5);
            this.Controls.Add(this.flatLabel4);
            this.Controls.Add(this.flatLabel3);
            this.Controls.Add(this.flatLabel1);
            this.Controls.Add(this.flatLabel2);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.txtMI);
            this.Controls.Add(this.txtBarangay);
            this.Controls.Add(this.txtFirstname);
            this.Controls.Add(this.txtContractNo);
            this.Controls.Add(this.txtProvince);
            this.Controls.Add(this.txtStreet);
            this.Controls.Add(this.txtLastname);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "UdStaff";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UdStaff";
            this.Load += new System.EventHandler(this.UdStaff_Load);
            this.GroupBox3.ResumeLayout(false);
            this.GroupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.DateTimePicker dtpDate;
        internal System.Windows.Forms.GroupBox GroupBox3;
        private FlatUI.FlatComboBox cbRole;
        private FlatUI.FlatTextBox txtConfirmPs;
        private FlatUI.FlatTextBox txtPassword;
        private FlatUI.FlatTextBox txtUsername;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label label6;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label5;
        private FlatUI.FlatLabel flatLabel8;
        private FlatUI.FlatLabel flatLabel7;
        private FlatUI.FlatLabel flatLabel6;
        private FlatUI.FlatLabel flatLabel5;
        private FlatUI.FlatLabel flatLabel4;
        private FlatUI.FlatLabel flatLabel3;
        private FlatUI.FlatLabel flatLabel1;
        private FlatUI.FlatLabel flatLabel2;
        private FlatUI.FlatTextBox txtCity;
        private FlatUI.FlatTextBox txtMI;
        private FlatUI.FlatTextBox txtBarangay;
        private FlatUI.FlatTextBox txtFirstname;
        private FlatUI.FlatTextBox txtContractNo;
        private FlatUI.FlatTextBox txtProvince;
        private FlatUI.FlatTextBox txtStreet;
        private FlatUI.FlatTextBox txtLastname;
        private System.Windows.Forms.Button button2;
        private FlatUI.FlatButton flatButton1;
        private System.Windows.Forms.PictureBox pbImage;
    }
}