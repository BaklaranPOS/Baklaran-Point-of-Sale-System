﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace FinalDeisgn
{
    public partial class Lod : Form
    {
        public Lod()
        {
            InitializeComponent();
        }

        private void Lod_Load(object sender, EventArgs e)
        {
            for (int i = 1; i <= 100; i++)
            {
                Thread.Sleep(15);
                bunifuCircleProgressbar1.Value = i;
                bunifuCircleProgressbar1.Update();

            }
            //for (int i = 1; i <= 100; i++)
            //{
            //    Thread.Sleep(15);
            //    bunifuProgressBar1.Value = i;
            //    bunifuProgressBar1.Update();

            //}
        }

        private void bunifuProgressBar1_progressChanged(object sender, EventArgs e)
        {

        }
    }
}
