﻿namespace FinalDeisgn
{
    partial class Staff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtCity = new FlatUI.FlatTextBox();
            this.txtMI = new FlatUI.FlatTextBox();
            this.txtBarangay = new FlatUI.FlatTextBox();
            this.txtFirstname = new FlatUI.FlatTextBox();
            this.txtProvince = new FlatUI.FlatTextBox();
            this.txtStreet = new FlatUI.FlatTextBox();
            this.txtLastname = new FlatUI.FlatTextBox();
            this.flatLabel2 = new FlatUI.FlatLabel();
            this.flatLabel1 = new FlatUI.FlatLabel();
            this.flatLabel3 = new FlatUI.FlatLabel();
            this.flatLabel4 = new FlatUI.FlatLabel();
            this.flatLabel5 = new FlatUI.FlatLabel();
            this.flatLabel6 = new FlatUI.FlatLabel();
            this.flatLabel7 = new FlatUI.FlatLabel();
            this.flatLabel8 = new FlatUI.FlatLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkBrowse = new System.Windows.Forms.LinkLabel();
            this.cbRole = new FlatUI.FlatComboBox();
            this.txtConfirmPs = new FlatUI.FlatTextBox();
            this.txtPassword = new FlatUI.FlatTextBox();
            this.txtUsername = new FlatUI.FlatTextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.btnInsert = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton3 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.lblID = new System.Windows.Forms.Label();
            this.lblpass = new System.Windows.Forms.Label();
            this.txtContractNo = new FlatUI.FlatTextBox();
            this.pbImage = new System.Windows.Forms.PictureBox();
            this.flatGroupBox1 = new FlatUI.FlatGroupBox();
            this.date = new FlatUI.FlatTextBox();
            this.txtID = new System.Windows.Forms.Label();
            this.txtDelete = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).BeginInit();
            this.flatGroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtCity
            // 
            this.txtCity.BackColor = System.Drawing.Color.Transparent;
            this.txtCity.FocusOnHover = false;
            this.txtCity.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCity.Location = new System.Drawing.Point(450, 81);
            this.txtCity.MaxLength = 32767;
            this.txtCity.Multiline = false;
            this.txtCity.Name = "txtCity";
            this.txtCity.ReadOnly = false;
            this.txtCity.Size = new System.Drawing.Size(209, 29);
            this.txtCity.TabIndex = 97;
            this.txtCity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCity.TextColor = System.Drawing.Color.Yellow;
            this.txtCity.UseSystemPasswordChar = false;
            // 
            // txtMI
            // 
            this.txtMI.BackColor = System.Drawing.Color.Transparent;
            this.txtMI.FocusOnHover = false;
            this.txtMI.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMI.Location = new System.Drawing.Point(448, 37);
            this.txtMI.MaxLength = 32767;
            this.txtMI.Multiline = false;
            this.txtMI.Name = "txtMI";
            this.txtMI.ReadOnly = false;
            this.txtMI.Size = new System.Drawing.Size(209, 29);
            this.txtMI.TabIndex = 96;
            this.txtMI.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtMI.TextColor = System.Drawing.Color.Yellow;
            this.txtMI.UseSystemPasswordChar = false;
            // 
            // txtBarangay
            // 
            this.txtBarangay.BackColor = System.Drawing.Color.Transparent;
            this.txtBarangay.FocusOnHover = false;
            this.txtBarangay.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBarangay.Location = new System.Drawing.Point(238, 82);
            this.txtBarangay.MaxLength = 32767;
            this.txtBarangay.Multiline = false;
            this.txtBarangay.Name = "txtBarangay";
            this.txtBarangay.ReadOnly = false;
            this.txtBarangay.Size = new System.Drawing.Size(194, 29);
            this.txtBarangay.TabIndex = 95;
            this.txtBarangay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBarangay.TextColor = System.Drawing.Color.Yellow;
            this.txtBarangay.UseSystemPasswordChar = false;
            // 
            // txtFirstname
            // 
            this.txtFirstname.BackColor = System.Drawing.Color.Transparent;
            this.txtFirstname.FocusOnHover = false;
            this.txtFirstname.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFirstname.Location = new System.Drawing.Point(238, 37);
            this.txtFirstname.MaxLength = 32767;
            this.txtFirstname.Multiline = false;
            this.txtFirstname.Name = "txtFirstname";
            this.txtFirstname.ReadOnly = false;
            this.txtFirstname.Size = new System.Drawing.Size(194, 29);
            this.txtFirstname.TabIndex = 94;
            this.txtFirstname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtFirstname.TextColor = System.Drawing.Color.Yellow;
            this.txtFirstname.UseSystemPasswordChar = false;
            // 
            // txtProvince
            // 
            this.txtProvince.BackColor = System.Drawing.Color.Transparent;
            this.txtProvince.FocusOnHover = false;
            this.txtProvince.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProvince.Location = new System.Drawing.Point(22, 127);
            this.txtProvince.MaxLength = 32767;
            this.txtProvince.Multiline = false;
            this.txtProvince.Name = "txtProvince";
            this.txtProvince.ReadOnly = false;
            this.txtProvince.Size = new System.Drawing.Size(194, 29);
            this.txtProvince.TabIndex = 92;
            this.txtProvince.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtProvince.TextColor = System.Drawing.Color.Yellow;
            this.txtProvince.UseSystemPasswordChar = false;
            // 
            // txtStreet
            // 
            this.txtStreet.BackColor = System.Drawing.Color.Transparent;
            this.txtStreet.FocusOnHover = false;
            this.txtStreet.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStreet.Location = new System.Drawing.Point(22, 82);
            this.txtStreet.MaxLength = 32767;
            this.txtStreet.Multiline = false;
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.ReadOnly = false;
            this.txtStreet.Size = new System.Drawing.Size(194, 29);
            this.txtStreet.TabIndex = 91;
            this.txtStreet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtStreet.TextColor = System.Drawing.Color.Yellow;
            this.txtStreet.UseSystemPasswordChar = false;
            // 
            // txtLastname
            // 
            this.txtLastname.BackColor = System.Drawing.Color.Transparent;
            this.txtLastname.FocusOnHover = false;
            this.txtLastname.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLastname.Location = new System.Drawing.Point(22, 37);
            this.txtLastname.MaxLength = 32767;
            this.txtLastname.Multiline = false;
            this.txtLastname.Name = "txtLastname";
            this.txtLastname.ReadOnly = false;
            this.txtLastname.Size = new System.Drawing.Size(194, 29);
            this.txtLastname.TabIndex = 90;
            this.txtLastname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtLastname.TextColor = System.Drawing.Color.Yellow;
            this.txtLastname.UseSystemPasswordChar = false;
            // 
            // flatLabel2
            // 
            this.flatLabel2.AutoSize = true;
            this.flatLabel2.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel2.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.flatLabel2.ForeColor = System.Drawing.Color.White;
            this.flatLabel2.Location = new System.Drawing.Point(19, 21);
            this.flatLabel2.Name = "flatLabel2";
            this.flatLabel2.Size = new System.Drawing.Size(55, 13);
            this.flatLabel2.TabIndex = 107;
            this.flatLabel2.Text = "Lastname";
            // 
            // flatLabel1
            // 
            this.flatLabel1.AutoSize = true;
            this.flatLabel1.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel1.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.flatLabel1.ForeColor = System.Drawing.Color.White;
            this.flatLabel1.Location = new System.Drawing.Point(445, 21);
            this.flatLabel1.Name = "flatLabel1";
            this.flatLabel1.Size = new System.Drawing.Size(75, 13);
            this.flatLabel1.TabIndex = 108;
            this.flatLabel1.Text = "Middle Initial";
            // 
            // flatLabel3
            // 
            this.flatLabel3.AutoSize = true;
            this.flatLabel3.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel3.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.flatLabel3.ForeColor = System.Drawing.Color.White;
            this.flatLabel3.Location = new System.Drawing.Point(235, 21);
            this.flatLabel3.Name = "flatLabel3";
            this.flatLabel3.Size = new System.Drawing.Size(57, 13);
            this.flatLabel3.TabIndex = 108;
            this.flatLabel3.Text = "Firstname";
            // 
            // flatLabel4
            // 
            this.flatLabel4.AutoSize = true;
            this.flatLabel4.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel4.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.flatLabel4.ForeColor = System.Drawing.Color.White;
            this.flatLabel4.Location = new System.Drawing.Point(19, 66);
            this.flatLabel4.Name = "flatLabel4";
            this.flatLabel4.Size = new System.Drawing.Size(37, 13);
            this.flatLabel4.TabIndex = 109;
            this.flatLabel4.Text = "Street";
            // 
            // flatLabel5
            // 
            this.flatLabel5.AutoSize = true;
            this.flatLabel5.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel5.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.flatLabel5.ForeColor = System.Drawing.Color.White;
            this.flatLabel5.Location = new System.Drawing.Point(235, 69);
            this.flatLabel5.Name = "flatLabel5";
            this.flatLabel5.Size = new System.Drawing.Size(55, 13);
            this.flatLabel5.TabIndex = 110;
            this.flatLabel5.Text = "Barangay";
            // 
            // flatLabel6
            // 
            this.flatLabel6.AutoSize = true;
            this.flatLabel6.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel6.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.flatLabel6.ForeColor = System.Drawing.Color.White;
            this.flatLabel6.Location = new System.Drawing.Point(445, 69);
            this.flatLabel6.Name = "flatLabel6";
            this.flatLabel6.Size = new System.Drawing.Size(26, 13);
            this.flatLabel6.TabIndex = 111;
            this.flatLabel6.Text = "City";
            // 
            // flatLabel7
            // 
            this.flatLabel7.AutoSize = true;
            this.flatLabel7.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel7.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.flatLabel7.ForeColor = System.Drawing.Color.White;
            this.flatLabel7.Location = new System.Drawing.Point(19, 114);
            this.flatLabel7.Name = "flatLabel7";
            this.flatLabel7.Size = new System.Drawing.Size(50, 13);
            this.flatLabel7.TabIndex = 112;
            this.flatLabel7.Text = "Province";
            // 
            // flatLabel8
            // 
            this.flatLabel8.AutoSize = true;
            this.flatLabel8.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel8.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.flatLabel8.ForeColor = System.Drawing.Color.White;
            this.flatLabel8.Location = new System.Drawing.Point(235, 114);
            this.flatLabel8.Name = "flatLabel8";
            this.flatLabel8.Size = new System.Drawing.Size(68, 13);
            this.flatLabel8.TabIndex = 113;
            this.flatLabel8.Text = "Contact No.";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.LinkColor = System.Drawing.Color.Black;
            this.linkLabel2.Location = new System.Drawing.Point(779, 172);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(79, 13);
            this.linkLabel2.TabIndex = 115;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Remove Image";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // linkBrowse
            // 
            this.linkBrowse.AutoSize = true;
            this.linkBrowse.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkBrowse.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.linkBrowse.LinkColor = System.Drawing.Color.Navy;
            this.linkBrowse.Location = new System.Drawing.Point(767, 149);
            this.linkBrowse.Name = "linkBrowse";
            this.linkBrowse.Size = new System.Drawing.Size(102, 20);
            this.linkBrowse.TabIndex = 114;
            this.linkBrowse.TabStop = true;
            this.linkBrowse.Text = "Browse Image";
            this.linkBrowse.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkBrowse_LinkClicked);
            // 
            // cbRole
            // 
            this.cbRole.BackColor = System.Drawing.Color.White;
            this.cbRole.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cbRole.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbRole.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.cbRole.ForeColor = System.Drawing.Color.Yellow;
            this.cbRole.FormattingEnabled = true;
            this.cbRole.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(168)))), ((int)(((byte)(109)))));
            this.cbRole.ItemHeight = 18;
            this.cbRole.Items.AddRange(new object[] {
            "Admin",
            "Cashier"});
            this.cbRole.Location = new System.Drawing.Point(22, 231);
            this.cbRole.Name = "cbRole";
            this.cbRole.Size = new System.Drawing.Size(194, 24);
            this.cbRole.TabIndex = 94;
            // 
            // txtConfirmPs
            // 
            this.txtConfirmPs.BackColor = System.Drawing.Color.Transparent;
            this.txtConfirmPs.FocusOnHover = false;
            this.txtConfirmPs.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConfirmPs.Location = new System.Drawing.Point(238, 229);
            this.txtConfirmPs.MaxLength = 32767;
            this.txtConfirmPs.Multiline = false;
            this.txtConfirmPs.Name = "txtConfirmPs";
            this.txtConfirmPs.ReadOnly = false;
            this.txtConfirmPs.Size = new System.Drawing.Size(194, 29);
            this.txtConfirmPs.TabIndex = 93;
            this.txtConfirmPs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtConfirmPs.TextColor = System.Drawing.Color.Yellow;
            this.txtConfirmPs.UseSystemPasswordChar = true;
            this.txtConfirmPs.TextChanged += new System.EventHandler(this.txtConfirmPs_TextChanged);
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.Color.Transparent;
            this.txtPassword.FocusOnHover = false;
            this.txtPassword.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(238, 181);
            this.txtPassword.MaxLength = 32767;
            this.txtPassword.Multiline = false;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.ReadOnly = false;
            this.txtPassword.Size = new System.Drawing.Size(194, 29);
            this.txtPassword.TabIndex = 92;
            this.txtPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtPassword.TextColor = System.Drawing.Color.Yellow;
            this.txtPassword.UseSystemPasswordChar = true;
            // 
            // txtUsername
            // 
            this.txtUsername.BackColor = System.Drawing.Color.Transparent;
            this.txtUsername.FocusOnHover = false;
            this.txtUsername.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsername.Location = new System.Drawing.Point(22, 181);
            this.txtUsername.MaxLength = 32767;
            this.txtUsername.Multiline = false;
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.ReadOnly = false;
            this.txtUsername.Size = new System.Drawing.Size(194, 29);
            this.txtUsername.TabIndex = 90;
            this.txtUsername.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtUsername.TextColor = System.Drawing.Color.Yellow;
            this.txtUsername.UseSystemPasswordChar = false;
            this.txtUsername.TextChanged += new System.EventHandler(this.txtUsername_TextChanged);
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label9.ForeColor = System.Drawing.Color.White;
            this.Label9.Location = new System.Drawing.Point(235, 213);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(106, 13);
            this.Label9.TabIndex = 12;
            this.Label9.Text = "Confirm Password :";
            this.Label9.Click += new System.EventHandler(this.Label9_Click);
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label7.ForeColor = System.Drawing.Color.White;
            this.Label7.Location = new System.Drawing.Point(19, 218);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(36, 13);
            this.Label7.TabIndex = 11;
            this.Label7.Text = "Role :";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.ForeColor = System.Drawing.Color.White;
            this.Label8.Location = new System.Drawing.Point(235, 165);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(62, 13);
            this.Label8.TabIndex = 9;
            this.Label8.Text = "Password :";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.ForeColor = System.Drawing.Color.White;
            this.Label5.Location = new System.Drawing.Point(19, 165);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(64, 13);
            this.Label5.TabIndex = 8;
            this.Label5.Text = "Username :";
            // 
            // btnInsert
            // 
            this.btnInsert.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnInsert.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnInsert.BorderRadius = 7;
            this.btnInsert.ButtonText = "Insert Staff";
            this.btnInsert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInsert.DisabledColor = System.Drawing.Color.Gray;
            this.btnInsert.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsert.ForeColor = System.Drawing.Color.Black;
            this.btnInsert.Iconcolor = System.Drawing.Color.Transparent;
            this.btnInsert.Iconimage = null;
            this.btnInsert.Iconimage_right = null;
            this.btnInsert.Iconimage_right_Selected = null;
            this.btnInsert.Iconimage_Selected = null;
            this.btnInsert.IconMarginLeft = 0;
            this.btnInsert.IconMarginRight = 0;
            this.btnInsert.IconRightVisible = true;
            this.btnInsert.IconRightZoom = 0D;
            this.btnInsert.IconVisible = true;
            this.btnInsert.IconZoom = 90D;
            this.btnInsert.IsTab = false;
            this.btnInsert.Location = new System.Drawing.Point(777, 189);
            this.btnInsert.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnInsert.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.btnInsert.OnHoverTextColor = System.Drawing.Color.White;
            this.btnInsert.selected = false;
            this.btnInsert.Size = new System.Drawing.Size(90, 38);
            this.btnInsert.TabIndex = 133;
            this.btnInsert.Text = "Insert Staff";
            this.btnInsert.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsert.Textcolor = System.Drawing.Color.White;
            this.btnInsert.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsert.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // bunifuFlatButton2
            // 
            this.bunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton2.BorderRadius = 7;
            this.bunifuFlatButton2.ButtonText = "Update Staff";
            this.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton2.ForeColor = System.Drawing.Color.Black;
            this.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.Iconimage = null;
            this.bunifuFlatButton2.Iconimage_right = null;
            this.bunifuFlatButton2.Iconimage_right_Selected = null;
            this.bunifuFlatButton2.Iconimage_Selected = null;
            this.bunifuFlatButton2.IconMarginLeft = 0;
            this.bunifuFlatButton2.IconMarginRight = 0;
            this.bunifuFlatButton2.IconRightVisible = true;
            this.bunifuFlatButton2.IconRightZoom = 0D;
            this.bunifuFlatButton2.IconVisible = true;
            this.bunifuFlatButton2.IconZoom = 90D;
            this.bunifuFlatButton2.IsTab = false;
            this.bunifuFlatButton2.Location = new System.Drawing.Point(728, 232);
            this.bunifuFlatButton2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.bunifuFlatButton2.Name = "bunifuFlatButton2";
            this.bunifuFlatButton2.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton2.selected = false;
            this.bunifuFlatButton2.Size = new System.Drawing.Size(90, 38);
            this.bunifuFlatButton2.TabIndex = 134;
            this.bunifuFlatButton2.Text = "Update Staff";
            this.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton2.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton2.Click += new System.EventHandler(this.bunifuFlatButton2_Click);
            // 
            // bunifuFlatButton3
            // 
            this.bunifuFlatButton3.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton3.BorderRadius = 7;
            this.bunifuFlatButton3.ButtonText = "Delete Staff";
            this.bunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton3.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton3.ForeColor = System.Drawing.Color.Black;
            this.bunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.Iconimage = null;
            this.bunifuFlatButton3.Iconimage_right = null;
            this.bunifuFlatButton3.Iconimage_right_Selected = null;
            this.bunifuFlatButton3.Iconimage_Selected = null;
            this.bunifuFlatButton3.IconMarginLeft = 0;
            this.bunifuFlatButton3.IconMarginRight = 0;
            this.bunifuFlatButton3.IconRightVisible = true;
            this.bunifuFlatButton3.IconRightZoom = 0D;
            this.bunifuFlatButton3.IconVisible = true;
            this.bunifuFlatButton3.IconZoom = 90D;
            this.bunifuFlatButton3.IsTab = false;
            this.bunifuFlatButton3.Location = new System.Drawing.Point(824, 232);
            this.bunifuFlatButton3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.bunifuFlatButton3.Name = "bunifuFlatButton3";
            this.bunifuFlatButton3.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton3.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.bunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.Red;
            this.bunifuFlatButton3.selected = false;
            this.bunifuFlatButton3.Size = new System.Drawing.Size(90, 38);
            this.bunifuFlatButton3.TabIndex = 135;
            this.bunifuFlatButton3.Text = "Delete Staff";
            this.bunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton3.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton3.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton3.Click += new System.EventHandler(this.bunifuFlatButton3_Click);
            // 
            // dataGridView1
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 8F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 8F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView1.Location = new System.Drawing.Point(0, 299);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 8F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(947, 605);
            this.dataGridView1.TabIndex = 136;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_CellMouseClick);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel1.LinkColor = System.Drawing.Color.Black;
            this.linkLabel1.Location = new System.Drawing.Point(895, 279);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(44, 13);
            this.linkLabel1.TabIndex = 137;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Refresh";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // dtpDate
            // 
            this.dtpDate.Location = new System.Drawing.Point(448, 134);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(209, 25);
            this.dtpDate.TabIndex = 138;
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.ForeColor = System.Drawing.Color.White;
            this.lblID.Location = new System.Drawing.Point(446, 226);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(12, 19);
            this.lblID.TabIndex = 139;
            this.lblID.Text = ".";
            this.lblID.Click += new System.EventHandler(this.lblID_Click);
            // 
            // lblpass
            // 
            this.lblpass.AutoSize = true;
            this.lblpass.Location = new System.Drawing.Point(447, 274);
            this.lblpass.Name = "lblpass";
            this.lblpass.Size = new System.Drawing.Size(10, 13);
            this.lblpass.TabIndex = 140;
            this.lblpass.Text = ".";
            this.lblpass.Click += new System.EventHandler(this.lblpass_Click);
            // 
            // txtContractNo
            // 
            this.txtContractNo.BackColor = System.Drawing.Color.Transparent;
            this.txtContractNo.FocusOnHover = false;
            this.txtContractNo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContractNo.Location = new System.Drawing.Point(238, 130);
            this.txtContractNo.MaxLength = 32767;
            this.txtContractNo.Multiline = false;
            this.txtContractNo.Name = "txtContractNo";
            this.txtContractNo.ReadOnly = false;
            this.txtContractNo.Size = new System.Drawing.Size(194, 29);
            this.txtContractNo.TabIndex = 93;
            this.txtContractNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtContractNo.TextColor = System.Drawing.Color.Yellow;
            this.txtContractNo.UseSystemPasswordChar = false;
            this.txtContractNo.TextChanged += new System.EventHandler(this.txtContractNo_TextChanged);
            this.txtContractNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtContractNo_KeyPress);
            // 
            // pbImage
            // 
            this.pbImage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.pbImage.Location = new System.Drawing.Point(738, 16);
            this.pbImage.Name = "pbImage";
            this.pbImage.Size = new System.Drawing.Size(166, 129);
            this.pbImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbImage.TabIndex = 116;
            this.pbImage.TabStop = false;
            // 
            // flatGroupBox1
            // 
            this.flatGroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.flatGroupBox1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.flatGroupBox1.Controls.Add(this.date);
            this.flatGroupBox1.Controls.Add(this.txtConfirmPs);
            this.flatGroupBox1.Controls.Add(this.cbRole);
            this.flatGroupBox1.Controls.Add(this.lblID);
            this.flatGroupBox1.Controls.Add(this.dtpDate);
            this.flatGroupBox1.Controls.Add(this.txtPassword);
            this.flatGroupBox1.Controls.Add(this.txtUsername);
            this.flatGroupBox1.Controls.Add(this.Label5);
            this.flatGroupBox1.Controls.Add(this.Label9);
            this.flatGroupBox1.Controls.Add(this.Label7);
            this.flatGroupBox1.Controls.Add(this.Label8);
            this.flatGroupBox1.Controls.Add(this.txtProvince);
            this.flatGroupBox1.Controls.Add(this.txtLastname);
            this.flatGroupBox1.Controls.Add(this.txtStreet);
            this.flatGroupBox1.Controls.Add(this.flatLabel8);
            this.flatGroupBox1.Controls.Add(this.txtContractNo);
            this.flatGroupBox1.Controls.Add(this.flatLabel7);
            this.flatGroupBox1.Controls.Add(this.txtFirstname);
            this.flatGroupBox1.Controls.Add(this.flatLabel6);
            this.flatGroupBox1.Controls.Add(this.txtBarangay);
            this.flatGroupBox1.Controls.Add(this.flatLabel5);
            this.flatGroupBox1.Controls.Add(this.txtMI);
            this.flatGroupBox1.Controls.Add(this.flatLabel4);
            this.flatGroupBox1.Controls.Add(this.txtCity);
            this.flatGroupBox1.Controls.Add(this.flatLabel3);
            this.flatGroupBox1.Controls.Add(this.flatLabel2);
            this.flatGroupBox1.Controls.Add(this.flatLabel1);
            this.flatGroupBox1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.flatGroupBox1.Location = new System.Drawing.Point(6, 8);
            this.flatGroupBox1.Name = "flatGroupBox1";
            this.flatGroupBox1.ShowText = true;
            this.flatGroupBox1.Size = new System.Drawing.Size(695, 284);
            this.flatGroupBox1.TabIndex = 141;
            this.flatGroupBox1.Click += new System.EventHandler(this.flatGroupBox1_Click);
            // 
            // date
            // 
            this.date.BackColor = System.Drawing.Color.Transparent;
            this.date.Enabled = false;
            this.date.FocusOnHover = false;
            this.date.Location = new System.Drawing.Point(448, 131);
            this.date.MaxLength = 32767;
            this.date.Multiline = false;
            this.date.Name = "date";
            this.date.ReadOnly = false;
            this.date.Size = new System.Drawing.Size(211, 29);
            this.date.TabIndex = 140;
            this.date.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.date.TextColor = System.Drawing.Color.Yellow;
            this.date.UseSystemPasswordChar = false;
            // 
            // txtID
            // 
            this.txtID.AutoSize = true;
            this.txtID.Font = new System.Drawing.Font("Microsoft Sans Serif", 1.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtID.Location = new System.Drawing.Point(868, 173);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(0, 2);
            this.txtID.TabIndex = 142;
            // 
            // txtDelete
            // 
            this.txtDelete.AutoSize = true;
            this.txtDelete.Location = new System.Drawing.Point(879, 189);
            this.txtDelete.Name = "txtDelete";
            this.txtDelete.Size = new System.Drawing.Size(0, 13);
            this.txtDelete.TabIndex = 143;
            // 
            // Staff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(84)))), ((int)(((byte)(84)))), ((int)(((byte)(84)))));
            this.ClientSize = new System.Drawing.Size(947, 609);
            this.Controls.Add(this.txtDelete);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.flatGroupBox1);
            this.Controls.Add(this.lblpass);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.bunifuFlatButton3);
            this.Controls.Add(this.bunifuFlatButton2);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.pbImage);
            this.Controls.Add(this.linkLabel2);
            this.Controls.Add(this.linkBrowse);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Staff";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "s";
            this.Load += new System.EventHandler(this.Staff_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).EndInit();
            this.flatGroupBox1.ResumeLayout(false);
            this.flatGroupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FlatUI.FlatTextBox txtCity;
        private FlatUI.FlatTextBox txtMI;
        private FlatUI.FlatTextBox txtBarangay;
        private FlatUI.FlatTextBox txtFirstname;
        private FlatUI.FlatTextBox txtProvince;
        private FlatUI.FlatTextBox txtStreet;
        private FlatUI.FlatTextBox txtLastname;
        private FlatUI.FlatLabel flatLabel2;
        private FlatUI.FlatLabel flatLabel1;
        private FlatUI.FlatLabel flatLabel3;
        private FlatUI.FlatLabel flatLabel4;
        private FlatUI.FlatLabel flatLabel5;
        private FlatUI.FlatLabel flatLabel6;
        private FlatUI.FlatLabel flatLabel7;
        private FlatUI.FlatLabel flatLabel8;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkBrowse;
        private System.Windows.Forms.PictureBox pbImage;
        private FlatUI.FlatComboBox cbRole;
        private FlatUI.FlatTextBox txtConfirmPs;
        private FlatUI.FlatTextBox txtPassword;
        private FlatUI.FlatTextBox txtUsername;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label5;
        private Bunifu.Framework.UI.BunifuFlatButton btnInsert;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton2;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label lblpass;
        private FlatUI.FlatTextBox txtContractNo;
        private FlatUI.FlatGroupBox flatGroupBox1;
        private FlatUI.FlatTextBox date;
        private System.Windows.Forms.Label txtID;
        private System.Windows.Forms.Label txtDelete;
    }
}