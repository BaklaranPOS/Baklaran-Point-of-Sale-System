﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Data;

namespace FinalDeisgn
{
   
    class Main
    {
        private MySqlConnection connection;
        public static MySqlConnection getconnection()
        {

            MySqlConnection connection = new MySqlConnection(@"Data Source=localhost;port=3306;Initial Catalog=dbstaff;User Id=root;password=''");
            return connection;
        }   

        public string Converter_string(string SQL)
        {
            try
            {
                MySqlConnection con = Main.getconnection();
                DataTable consultantable = new DataTable();
                string StringConsultant;

                MySqlDataAdapter consultantdataAdapter = new MySqlDataAdapter(SQL, con);
                consultantdataAdapter.Fill(consultantable);

                foreach (DataRow myrow in consultantable.Rows)
                {
                    StringConsultant = Convert.ToString(myrow[0]);
                    return StringConsultant;
                }


            }
            catch
            {
                throw;
            }
            return "0";
        }
        public void Execute(string SQL)
        {
            try
            {
                MySqlConnection con = Main.getconnection();
                DataTable consultantable = new DataTable();
                MySqlDataAdapter Adapter = new MySqlDataAdapter(SQL, con);
                Adapter.Fill(consultantable);


            }
            catch
            {
                throw;
            }
        }

    }
}
