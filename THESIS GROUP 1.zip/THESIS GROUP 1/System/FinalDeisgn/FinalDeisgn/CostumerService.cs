﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace FinalDeisgn
{
    public partial class CostumerService : Form
    {

        MySqlConnection con = new MySqlConnection(@"Data Source=localhost;port=3306;Initial Catalog=dbstaff;User Id=root;password=''");
        MySqlDataReader dr;
        MySqlCommand cmd = new MySqlCommand();
        double Total;
        public CostumerService()
        {
            InitializeComponent();
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {

            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO `tblcostumer`(`Date`, `Invoice`, `StaffName`, `AmountRefund`, `TotalRefund`, `Reason`,`Price`)  values ('" + dtpDate.Value.ToString("yyyy-MM-dd") + "','" + txtInvoice.Text + "','" + txtStaff.Text + "','" + txtAmount.Text + "','" + txtTotal.Text + "','" + txtReason.Text + "','" + txtPrice.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Return Seccesfully Saved");
            click();

            date.ResetText();
            txtInvoice.ResetText();
            txtStaff.ResetText();
            txtTotal.ResetText();
            txtReason.ResetText();
            txtPrice.ResetText();
            txtInvoice.ResetText();
            txtAmount.ResetText();
        }

        private void txtReason_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new MySqlCommand("Select * from tblmain where CustumerNo like '" + txtInvoice.Text + "'", con);
                cmd.ExecuteNonQuery();
                dr = cmd.ExecuteReader();
                dr.Read();
                if (dr.HasRows)
                {
                    txtPrice.Text = dr.GetValue(9).ToString();
                    bunifuFlatButton2.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Costumer Not Found !");
                    bunifuFlatButton2.Enabled = false;
                    txtAmount.ResetText();
                    txtInvoice.ResetText();
                    txtPrice.ResetText();
                    txtReason.ResetText();
                    txtStaff.ResetText();
                    txtTotal.ResetText();


                }
                con.Close();
            }
                
                catch (Exception ex) 
            { 
                    return; 
                }
                
            }

        private void txtAmount_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Total = double.Parse(txtPrice.Text) - double.Parse(txtAmount.Text);
                txtTotal.Text = Total.ToString("P#,##0.00");
            }
            catch (Exception ex) { }
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {

            con.Open();
            cmd = new MySqlCommand("Select * from tblcostumer where `Date` between '" + a.Value.ToString("yyyy-MM-dd") + "' and '" + b.Value.ToString("yyyy-MM-dd") + "'", con);
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            cmd.ExecuteNonQuery();
            dr = cmd.ExecuteReader();
            dr.Read();
            con.Close();
           
           
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Are you sure to delete this product ?", "Delete", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {
                con.Open();
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "DELETE FROM `tblcostumer` where `ID` = '" + txtID.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
                dataGridView2.DataSource = dt;
                MessageBox.Show("Record Deleted");
                con.Close();
                click();
            }
        }

        private void txtAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;

            }
        }

        private void txtTotal_TextChanged(object sender, EventArgs e)
        {
            if (Total < 0)
            {
                MessageBox.Show("Over Refund");
                btnReturn.Enabled = false;

            }
            else
            {
                btnReturn.Enabled = true;
            }
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                txtInvoice.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                txtPrice.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
                txtStaff.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                txtAmount.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                txtTotal.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                txtReason.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
                date.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
               
            }
            if (e.RowIndex >= 0) {

                bunifuFlatButton1.Enabled = false;

            }
        }

        private void CostumerService_Load(object sender, EventArgs e)
        {
            btnReturn.Enabled = false;
            //try
            //{
                con.Open();
                cmd = new MySqlCommand("Select * from tblcostumer ", con);
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                cmd.ExecuteNonQuery();
                dr = cmd.ExecuteReader();
                dr.Read();
                con.Close();
                
            //}
            //catch (Exception ex) { return; }

                richTextBox1.Visible = false;
            txtReason.Visible = false;
            label9.Visible = false;
            dataGridView2.Visible = true;
            btnReturn.Visible = false;
            label10.Visible = false;
            label12.Visible = false;
            label1.Visible = false;
            label13.Visible = false;
            label17.Visible = false;
            label4.Visible = false;
           
            txtTotal.Visible = false;
            txtStaff.Visible = false;
            txtPrice.Visible = false;
            txtAmount.Visible = false;
            txtInvoice.Visible = false;
            button1.Visible = false;
            date.Visible = false;
        }

       

        private void click() 
        {
            con.Open();
            cmd = new MySqlCommand("Select * from tblcostumer ", con);
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            cmd.ExecuteNonQuery();
            dr = cmd.ExecuteReader();
            dr.Read();
            con.Close();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //try
            //{
                string d1 = a.Value.ToString("yyyy-MM-dd");
                string d2 = b.Value.ToString("yyyy-MM-dd");
                Sample sr = new Sample();
                sr.GenerateReport(d1, d2);
                sr.Show();
                this.Hide();
            //}
            //catch (Exception ex)
            //{
            //    return;
            //}
            //finally
            //{
            //    MessageBox.Show("There is a problem in loading the report");
            //}
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void txtTotal_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;

            }
        }

        private void txtTotal_Click(object sender, EventArgs e)
        {

        }

        private void txtTotal_TextChanged_1(object sender, EventArgs e)
        {
             if (Total < 0)
            {
                MessageBox.Show("Over Refund");
                btnReturn.Enabled = false;

            }
            else
            {
                btnReturn.Enabled = true;
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new MySqlCommand("Select * from tblmain where DateSold like '" + dtpDate.Value.ToString("yyyy-MM-dd") + "'", con);
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
                dataGridView2.DataSource = dt;
                cmd.ExecuteNonQuery();
                dr = cmd.ExecuteReader();
                dr.Read();
                con.Close();
            }

            catch (Exception ex)
            {
                return;
            }
            finally {
                con.Dispose();
            }
                
        }

        private void dataGridView2_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {




            //con.Open();
            //cmd = new MySqlCommand("Select * from tblmain where CustumerNo like '" + txtInvoice.Text + "'", con);
            //cmd.ExecuteNonQuery();
            //dr = cmd.ExecuteReader();
            //dr.Read();
            //if (dr.HasRows)
            //{
            //    txtPrice.Text = dr.GetValue(9).ToString();
            //    bunifuFlatButton2.Enabled = true;
            //}
            //else
            //{
            //    MessageBox.Show("Costumer Not Found !");
            //    bunifuFlatButton2.Enabled = false;
            //    txtAmount.ResetText();
            //    txtInvoice.ResetText();
            //    txtPrice.ResetText();
            //    txtReason.ResetText();
            //    txtStaff.ResetText();
            //    txtTotal.ResetText();


            //}
            //con.Close();


            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView2.Rows[e.RowIndex];
                txtPrice.Text = dataGridView2.CurrentRow.Cells[9].Value.ToString();
                txtInvoice.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();


            }




            txtReason.Visible = true;
            label9.Visible = true;
            dataGridView2.Visible = false;
            btnReturn.Visible = true;
            label10.Visible = true;
            label12.Visible = true;
            label1.Visible = true;
            label13.Visible = true;
            label17.Visible = true;
            label4.Visible = true;
            txtTotal.Visible = true;
            txtStaff.Visible = true;
            txtPrice.Visible = true;
            txtAmount.Visible = true;
            txtInvoice.Visible = true;
            button1.Visible = true;
            date.Visible = true;




        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellMouseClick_1(object sender, DataGridViewCellMouseEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellMouseClick_1(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                txtID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            }
        }

        }
    }


