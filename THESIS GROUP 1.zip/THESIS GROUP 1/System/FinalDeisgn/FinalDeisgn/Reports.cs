﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Threading;
namespace FinalDeisgn
{
    public partial class Reports : Form
    {



        MySqlConnection con = new MySqlConnection(@"Data Source=localhost;port=3306;Initial Catalog=dbstaff;User Id=root;password=''");
        MySqlDataReader dr;
        MySqlCommand cmd = new MySqlCommand();

        
        double Price;
        double Quantity;
        double Total;
        double Cash;
        double Change;
        double TotalAmount;
        double tot;
        string desc;
        public Reports()
        {
            InitializeComponent();
        }




        private void GetTotal()
        {
            double total = 0;
            for (int i = 0; i < dataGridView1.Rows.Count - 1; ++i)
            {
                total += double.Parse(dataGridView1[9, i].Value.ToString());

            }
            lblTotal.Text = total.ToString("#,##0.00");
            tot = total;
        }


        private void btnReturn_Click(object sender, EventArgs e)
        {

            con.Open();
            cmd = new MySqlCommand("Select *  from tblmain where `DateSold` between '" + dateFrom.Value.ToString("yyyy-MM-dd") + "' and '" + dateto.Value.ToString("yyyy-MM-dd") + "'", con);
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            cmd.ExecuteNonQuery();
            dr = cmd.ExecuteReader();
            dr.Read();
            con.Close();
            GetTotal();
            if (dr.HasRows)
            {
                con.Open();
                dateFrom.Text = dr.GetValue(5).ToString();
                cmd = new MySqlCommand("select * from tblmain", con);
                con.Close();

                //try
                //{
                //    dataGridView2.Rows.Add(txtDesc.Text, txtPrice.Text, txtQuanity.Text, txtID.Text, double.Parse(txtPrice.Text) * int.Parse(txtQuanity.Text));
                //    GetTotal();

                //}
                //catch (Exception ex)
                //{
                //    MessageBox.Show("");
                //}
            }
        }

        private void load() {
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM  tblmain ";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void Reports_Load(object sender, EventArgs e)
        {
            
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM  tblmain ";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
            GetTotal();
            bunifuCircleProgressbar1.Visible = true;


            for (int i = 1; i <= 100; i++)
            {
                Thread.Sleep(25);
                bunifuCircleProgressbar1.Value = i;
                bunifuCircleProgressbar1.Update();


            }
            if (bunifuCircleProgressbar1.Value == 100)
            {
                bunifuCircleProgressbar1.Visible = false;
               
                dataGridView1.Visible = true;
                //flatLabel4.Visible = false;
            }


        }

        private void lblLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                SaleReportcs sl = new SaleReportcs();
                sl.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                return;
            }
            finally 
            
            {
                MessageBox.Show("There is a problem in loading the report");
            }
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Are you sure to delete this product ?", "Delete", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {
                con.Open();
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "DELETE FROM `tblmain` WHERE `CustumerNo` = '" + txtID.Text + "'";
                cmd.ExecuteNonQuery();
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                MessageBox.Show("Record Sucessfully Deleted");
                con.Close();
                load();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void flatLabel4_Click(object sender, EventArgs e)
        {

        }

        private void lblTotal_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                txtID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            }
        }

        private void dataGridView1_CellContentClick_2(object sender, DataGridViewCellEventArgs e)
        {
        
        }
}
}
