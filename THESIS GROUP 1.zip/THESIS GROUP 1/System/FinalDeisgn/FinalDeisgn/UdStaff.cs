﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
namespace FinalDeisgn
{
    public partial class UdStaff : Form
    {

        MySqlConnection con = new MySqlConnection(@"Data Source=localhost;port=3306;Initial Catalog=dbstaff;User Id=root;password=''");
        MySqlDataReader dr;
        MySqlCommand cmd = new MySqlCommand();

        public string user;
        public string role1;

        public UdStaff()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 fr = new Form1(role1);
            fr.Show();
            this.Hide();
        }

        private void UdStaff_Load(object sender, EventArgs e)
        {
           
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "UPDATE `tblstaff` SET `Firstname`='" + txtFirstname.Text + "',`Lastname`='" + txtLastname.Text + "',`MI`='" + txtMI + "',`Street`='" + txtStreet + "',`Barangay`='" + txtBarangay.Text + "',`City`='" + txtCity + "',`Province`='" + txtProvince + "',`ContactNo`='" + txtContractNo + "',`Username`='" + txtUsername.Text + "',`Password`='" + txtPassword + "',`Role`='" + cbRole.Text + "',`Date`='" + dtpDate.Text + "',`Image`='" + pbImage.Image + "' where ID = '" + lblID.Text + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            MessageBox.Show("Product Sucessfully Updated");
            con.Close();
        }
    }
}
