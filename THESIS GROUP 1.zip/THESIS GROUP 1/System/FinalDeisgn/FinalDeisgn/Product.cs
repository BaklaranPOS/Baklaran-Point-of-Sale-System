﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Microsoft.VisualBasic;
namespace FinalDeisgn
{
    public partial class Product : Form
    {
        MySqlConnection con = new MySqlConnection(@"Data Source=localhost;port=3306;Initial Catalog=dbstaff;User Id=root;password=''");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataReader dr;
        public Product()
        {
            InitializeComponent();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new MySqlCommand("INSERT INTO `tblproduct`(`ProdID`, `ProdDesc`, `Price`, `Category`) values ('" + txtID.Text + "','" + txtDesc.Text + "','" + txtPrice.Text + "', '" + cbCategory.Text + "')", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Product Inserted");
            lo();
            txtDesc.ResetText();
            txtID.ResetText();
            txtPrice.ResetText();
            cbCategory.ResetText();

        }
        private void link() 
        
        {
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM  tblproduct ";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView2.DataSource = dt;

            con.Close();
        }
        private void lo() {

            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM  tblproduct ";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView2.DataSource = dt;

            con.Close();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "UPDATE `tblproduct` SET `Price`= '" + txtPrice.Text + "',`ProdDesc`= '" + txtDesc.Text + "',`Category`= '" + cbCategory.Text + "' WHERE `ProdID`='" + txtID.Text + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView2.DataSource = dt;
            MessageBox.Show("Staff Sucessfully Updated");
           
            con.Close();
            lo();
            txtDesc.ResetText();
            txtID.ResetText();
            txtPrice.ResetText();
            cbCategory.ResetText();
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM  tblproduct ";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView2.DataSource = dt;

            con.Close();
        }

        private void dataGridView2_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView2.Rows[e.RowIndex];
                txtDesc.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
                cbCategory.Text = dataGridView2.CurrentRow.Cells[3].Value.ToString();
                txtPrice.Text = dataGridView2.CurrentRow.Cells[2].Value.ToString();
                txtID.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
            }
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Are you sure to delete this product ?", "Delete", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {
                con.Open();
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "DELETE FROM `tblproduct` where `ProdID` = '" + txtID.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
                dataGridView2.DataSource = dt;
                MessageBox.Show("Product Sucessfully Deleted");
               
                con.Close();
                lo();
            }
            //if (
            //    dataGridView2.SelectedRows >= 0;
            //    ){}
        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void Product_Load(object sender, EventArgs e)
        {
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM  tblproduct ";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView2.DataSource = dt;

            con.Close();
        }

        private void btnReturn_KeyUp(object sender, KeyEventArgs e)
        {
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM  tblproduct ";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView2.DataSource = dt;

            con.Close();
        }


        //public void LoadStaffs()
        //{
        //    try
        //    {
        //        con.Open();
        //        cmd = new MySqlCommand("Select * from tblproduct where ProdDesc like '" + button1.Text + "'", con);
        //        cmd.ExecuteNonQuery();
        //        DataTable dt = new DataTable();
        //        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
        //        da.Fill(dt);
        //        dataGridView2.DataSource = dt;
        //        dr = cmd.ExecuteReader();
        //        dr.Read();
        //        con.Close();

              
        //    }
        //    catch (Exception ex)
        //    {
        //        Interaction.MsgBox(ex.Message);
        //    }
        //    finally
        //    {
        //        //SQLConn.cmd.Dispose();
        //        //SQLConn.conn.Close();
        //    }
    

        

        private void button1_Click(object sender, EventArgs e)
        {
            //con.Open();
            //MySqlDataAdapter SDA = new MySqlDataAdapter("SELECT ProdID`, `ProdDesc`, `Price`, `Category` FROM tblproduct where ProdDesc Like '" + textSearch.Text + "%'", con);
            //DataTable DATA = new DataTable();
            //SDA.Fill(DATA);
            //dataGridView2.DataSource = DATA;
            //con.Close();   
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            con.Open();
            MySqlDataAdapter SDA = new MySqlDataAdapter("SELECT ProdID,ProdDesc,Price,Category FROM tblproduct where ProdDesc Like '" + txtSearch.Text + "%'", con);
            DataTable DATA = new DataTable();
            SDA.Fill(DATA);
            dataGridView2.DataSource = DATA;
            con.Close(); 
        }
    

        
    }
}
