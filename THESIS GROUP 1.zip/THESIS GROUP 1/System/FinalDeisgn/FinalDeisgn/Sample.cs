﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using MySql.Data.MySqlClient;
namespace FinalDeisgn
{
    public partial class Sample : Form
    {
        MySqlConnection con = new MySqlConnection(@"Data Source=localhost;port=3306;Initial Catalog=dbstaff;User Id=root;password=''");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataReader dr;

        public Sample()
        {
            InitializeComponent();
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {
           // GenerateReport();
        }
        public void GenerateReport(string d1,string d2)
        {
            dsReportC ds = new dsReportC();
            MySqlDataAdapter da = new MySqlDataAdapter();
            con.Open();
            da.SelectCommand = new MySqlCommand("Select * from tblcostumer where Date between '"+ d1 + "' and '" + d2 + "'",con);
            da.Fill(ds,"DataTable1");
            Sample1 sample = new Sample1();
            sample.Load(Application.StartupPath + @"\Sample1.rpt");
            sample.SetDataSource(ds.Tables["DataTable1"]);
            crystalReportViewer1.ReportSource = sample;
            crystalReportViewer1.Refresh();
            con.Close();
        }

        private void crystalReportViewer1_Load_1(object sender, EventArgs e)
        {
           // GenerateReport();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
        }


    }
}
