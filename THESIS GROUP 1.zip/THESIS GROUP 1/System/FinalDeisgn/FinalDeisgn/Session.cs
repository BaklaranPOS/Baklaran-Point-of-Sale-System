﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Microsoft.VisualBasic;
namespace FinalDeisgn
{
    public partial class Session : Form
    {


        MySqlConnection con = new MySqlConnection(@"Data Source=localhost;port=3306;Initial Catalog=dbstaff;User Id=root;password=''");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataReader dr;
          public string role1;
        public Session()
        {
            InitializeComponent();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM  tblsession ";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            bunifuCustomDataGrid1.DataSource = dt;

            con.Close();
        }
        private void display() {
            
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM  tblsession ";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            bunifuCustomDataGrid1.DataSource = dt;

            con.Close();
        }
        public void LoadStaffs(string search)
        {
            try
            {
                SQLConn.conn.Open();
                SQLConn.sqL = "SELECT ProdID, CONCAT(Lastname, ', ', Firstname, ' ', MI) as ClientName, CONCAT(Street, ', ', Barangay, ', ', City , ', ', Province) as Address, ContactNo, username, role FROM tblstaff WHERE Lastname LIKE '" + search.Trim() + "%' ORDER By Lastname";
                SQLConn.ConnDB();
                SQLConn.cmd = new MySqlCommand(SQLConn.sqL, SQLConn.conn);
                SQLConn.dr = SQLConn.cmd.ExecuteReader();
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(dt);



            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            finally
            {
                SQLConn.cmd.Dispose();
                SQLConn.conn.Close();
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            SQLConn.strSearch = Interaction.InputBox("ENTER LAST NAME OF THE STAFF.", "Search Staff", " ");

            if (SQLConn.strSearch.Length >= 1)
            {
                LoadStaffs(SQLConn.strSearch.Trim());
            }
            else if (string.IsNullOrEmpty(SQLConn.strSearch))
            {
                return;
            }
            //con.Open();
            //cmd = new MySqlCommand("Select *  from tblhistory where `Date` = '" + dateto.Text + "'", con);
            //cmd.ExecuteNonQuery();
            //DataTable dt = new DataTable();
            //MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            //da.Fill(dt);
            //dataGridView1.DataSource = dt;
            //cmd.ExecuteNonQuery();
            //dr = cmd.ExecuteReader();
            //dr.Read();
            //con.Close();
           
            }

        private void dateto_ValueChanged(object sender, EventArgs e)
        {

            //con.Open();
            //cmd = new MySqlCommand("Select *  from tblhistory where  Date like '" + dateto.Text + "'", con);
            //cmd.ExecuteNonQuery();
            //DataTable dt = new DataTable();
            //MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            //da.Fill(dt);
           
            //cmd.ExecuteNonQuery();
            //dr = cmd.ExecuteReader();
            //dr.Read();
            //con.Close();
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "DELETE FROM `tblhistory`";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
           
            MessageBox.Show("Product Sucessfully Deleted");
            con.Close();
        }

        private void ListView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtDesc_TextChanged(object sender, EventArgs e)
        {
            con.Open();
            MySqlDataAdapter SDA = new MySqlDataAdapter("SELECT ID,ClientName,TimeAndDate,Interaction FROM tblsession where ClientName Like '" + txtDesc.Text + "%'", con);
            DataTable DATA = new DataTable();
            SDA.Fill(DATA);
            bunifuCustomDataGrid1.DataSource = DATA;
            con.Close(); 
        }

        private void bunifuCustomDataGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Are you sure to delete this product ?", "Delete", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {
                con.Open();
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "DELETE FROM `tblsession` where `ID` = '" + label1.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
                bunifuCustomDataGrid1.DataSource = dt;
                MessageBox.Show("Record Deleted");
                
                con.Close();
                display();
                
            }
        }

        private void bunifuCustomDataGrid1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.bunifuCustomDataGrid1.Rows[e.RowIndex];
                label1.Text = bunifuCustomDataGrid1.CurrentRow.Cells[0].Value.ToString();
            }
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Are you sure to delete this product ?", "Delete", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {
                con.Open();
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "DELETE FROM `tblsession` where 1";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
                bunifuCustomDataGrid1.DataSource = dt;
                MessageBox.Show("Record Deleted");

                con.Close();
                display();

            }
        }
          
        }
    }

