﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Threading;
using Microsoft.VisualBasic;
namespace FinalDeisgn
{
    public partial class Login : Form{
    

        MySqlConnection con = new MySqlConnection(@"Data Source=localhost;port=3306;Initial Catalog=dbstaff;User Id=root;password=''");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataReader dr;

        public string user;
        public string role;


        public Login()
        {
            InitializeComponent();
        }
         public static string ID = "1";
        public static string Username = "1";

         MySqlConnection  connection  = Main.getconnection();

        private void Login_Load(object sender, EventArgs e)
        {
            bunifuCircleProgressbar1.Visible = false;
            flatLabel4.Visible = false;}
           

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToString("hh:mm: tt");
            lblDateTime.Text =DateTime.Now.ToString("MMMM dd, yyyy");
            
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            try
            {
                pictureBox1.Visible = false;
                flatLabel4.Visible = true;
                con.Open();
                cmd = new MySqlCommand("Select * from tblstaff where Username like '" + txtUser.Text + "' and Password like '" + txtPassword.Text + "'", con);
                cmd.ExecuteNonQuery();
                dr = cmd.ExecuteReader();
                dr.Read();

                if (dr.HasRows)
                {

                    bunifuCircleProgressbar1.Visible = true;
                    flatLabel4.Visible = true;



                    for (int i = 1; i <= 100; i++)
                    {
                        Thread.Sleep(15);
                        bunifuCircleProgressbar1.Value = i;
                        bunifuCircleProgressbar1.Update();

                    }

                    role = dr.GetValue(11).ToString();

                    Form1 fr = new Form1(role);
                    fr.Show();
                    this.Hide();
                    con.Close();
                    con.Open();
                    cmd = new MySqlCommand("INSERT INTO `tblhistory`(`Username`, `Date`, `TimeLogIn`) values ('" + txtUser.Text + "','" + lblDateTime.Text + "', '" + lblTime.Text + "')", con);
                    cmd.ExecuteNonQuery();
                    con.Close();



                }
                else
                {

                    MessageBox.Show("Invalid Password");
                    MessageBox.Show("There was a problem in opening you database check is it open or close you", "This system will automatically restart");
                    Login lg = new Login();
                    lg.Show();
                    this.Hide();

                }
            }
            catch (Exception ex)
            {
                return;
            }
            finally
            {
                con.Close();
                con.Dispose();

            }

            LoginForm();
        }


        private void LoginForm()
        {
            try
            {
                SQLConn.sqL = "SELECT * FROM tblstaff WHERE Username = '" + txtUser.Text + "' AND Password = '" + txtPassword.Text + "'";
                SQLConn.ConnDB();
                SQLConn.cmd = new MySqlCommand(SQLConn.sqL, SQLConn.conn);
                SQLConn.dr = SQLConn.cmd.ExecuteReader();

                if (SQLConn.dr.Read() == true)
                {

                    if (SQLConn.dr["Role"].ToString().ToUpper() == "ADMIN")
                    {
                        Form1 m = new Form1(SQLConn.dr["Username"].ToString(), Convert.ToInt32(SQLConn.dr["ID"]));
                        m.Show();
                        this.Hide();
                    }
                    else
                    {

                    }
                }
                else
                {
                    Interaction.MsgBox("Invalid Password. Please try again.", MsgBoxStyle.Exclamation, "Login");
                }

            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            finally
            {
                SQLConn.cmd.Dispose();
                SQLConn.conn.Close();
            }
        }


        private void txtUser_TextChanged(object sender, EventArgs e)
        {
             
        }
        private void keypress() {
            try
            {
                pictureBox1.Visible = false;
                flatLabel4.Visible = true;
                con.Open();
                cmd = new MySqlCommand("Select * from tblstaff where Username like '" + txtUser.Text + "' and Password like '" + txtPassword.Text + "'", con);
                cmd.ExecuteNonQuery();
                dr = cmd.ExecuteReader();
                dr.Read();

                if (dr.HasRows)
                {

                    bunifuCircleProgressbar1.Visible = true;
                    flatLabel4.Visible = true;



                    for (int i = 1; i <= 100; i++)
                    {
                        Thread.Sleep(15);
                        bunifuCircleProgressbar1.Value = i;
                        bunifuCircleProgressbar1.Update();

                    }

                    role = dr.GetValue(11).ToString();

                    Form1 fr = new Form1(role);
                    fr.Show();
                    this.Hide();
                    con.Close();
                    con.Open();
                    cmd = new MySqlCommand("INSERT INTO `tblhistory`(`Username`, `Date`, `TimeLogIn`) values ('" + txtUser.Text + "','" + lblDateTime.Text + "', '" + lblTime.Text + "')", con);
                    cmd.ExecuteNonQuery();
                    con.Close();



                }
                else
                {

                    MessageBox.Show("Invalid Password");
                    MessageBox.Show("There was a problem in opening you database check is it open or close you", "This system will automatically restart");
                    Login lg = new Login();
                    lg.Show();
                    this.Hide();

                }
            }
            catch (Exception ex)
            {
                return;
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
           
        }

        private void flatButton1_Enter(object sender, EventArgs e)
        {
            
        }
        private void enter()
        {
            try
            {
                pictureBox1.Visible = false;
                flatLabel4.Visible = true;
                con.Open();
                cmd = new MySqlCommand("Select * from tblstaff where Username like '" + txtUser.Text + "' and Password like '" + txtPassword.Text + "'", con);
                cmd.ExecuteNonQuery();
                dr = cmd.ExecuteReader();
                dr.Read();

                if (dr.HasRows)
                {

                    bunifuCircleProgressbar1.Visible = true;
                    flatLabel4.Visible = true;



                    for (int i = 1; i <= 100; i++)
                    {
                        Thread.Sleep(15);
                        bunifuCircleProgressbar1.Value = i;
                        bunifuCircleProgressbar1.Update();

                    }

                    role = dr.GetValue(11).ToString();

                    Form1 fr = new Form1(role);
                    fr.Show();
                    this.Hide();
                    con.Close();
                    con.Open();
                    cmd = new MySqlCommand("INSERT INTO `tblhistory`(`Username`, `Date`, `TimeLogIn`) values ('" + txtUser.Text + "','" + lblDateTime.Text + "', '" + lblTime.Text + "')", con);
                    cmd.ExecuteNonQuery();
                    con.Close();



                }
                else
                {

                    MessageBox.Show("Invalid Password");
                    MessageBox.Show("There was a problem in opening you database check is it open or close you", "This system will automatically restart");
                    Login lg = new Login();
                    lg.Show();
                    this.Hide();

                }
            }
            catch (Exception ex)
            {
                return;
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
           
           
        
        }

        private void flatButton1_KeyDown(object sender, KeyEventArgs e)
        {
            enter();
        }

        private void Log (){
            if ((txtUser.Text == ""))
            {
                MessageBox.Show("Please enter your UserName");
            }

            else if ((txtPassword.Text == ""))
            {
                MessageBox.Show("Please enter your name ");
            }
            else
            {
                string war = "login";
                Main code = new Main();
                string SqlID = "Select Firstname from tblstaff where  Username = '" + Convert.ToString(txtUser.Text) + "' AND Password = '" + Convert.ToString(txtPassword.Text) + "'";
                ID = code.Converter_string(SqlID).ToString();

                if (ID != "")
                {
                    string SqlLoginName = "Select Username From tblstaff Where Firstname = '" + Convert.ToString(ID) + "'";
                    Username = code.Converter_string(SqlLoginName).ToString();
                    code.Execute(@"INSERT INTO tblsession values  ('" + txtUser.Text + "','" + ID + "','" + war + "','" + DateTime.Now + "')");


                    //Form1 MAIN = new Form1(role);

                    //this.Hide();
                    //MAIN.Show();



                }



                else
                {
                    MessageBox.Show("Invalid UserName");
                    txtPassword.Text = "";
                }
            }


                


    }

        private void Loa(){
            try
            {
                pictureBox1.Visible = false;
                flatLabel4.Visible = true;
                con.Open();
                cmd = new MySqlCommand("Select * from tblstaff where Username like '" + txtUser.Text + "' and Password like '" + txtPassword.Text + "'", con);
                cmd.ExecuteNonQuery();
                dr = cmd.ExecuteReader();
                dr.Read();

                if (dr.HasRows)
                {

                    bunifuCircleProgressbar1.Visible = true;
                    flatLabel4.Visible = true;



                    for (int i = 1; i <= 100; i++)
                    {
                        Thread.Sleep(15);
                        bunifuCircleProgressbar1.Value = i;
                        bunifuCircleProgressbar1.Update();

                    }

                    role = dr.GetValue(11).ToString();

                    Form1 fr = new Form1(role);
                    fr.Show();
                    this.Hide();
                    con.Close();
                    Log();
                    // cmd = new MySqlCommand("INSERT INTO `tblhistory`(`Username`, `Date`, `TimeLogIn`) values ('" + txtUser.Text + "','" + lblDateTime.Text + "', '" + lblTime.Text + "')", con);
                    //cmd.ExecuteNonQuery();




                }
                else
                {

                    MessageBox.Show("Invalid Password");
                    MessageBox.Show("There was a problem in opening you database check is it open or close you", "This system will automatically restart");
                    Login lg = new Login();
                    lg.Show();
                    this.Hide();

                }
            }
            catch (Exception ex)
            {
                return;
            }
            finally
            {
                con.Close();
                con.Dispose();

            }
            
            
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {

            try
            {
                pictureBox1.Visible = false;
                flatLabel4.Visible = true;
                con.Open();
                cmd = new MySqlCommand("Select * from tblstaff where Username like '" + txtUser.Text + "' and Password like '" + txtPassword.Text + "'", con);
                cmd.ExecuteNonQuery();
                dr = cmd.ExecuteReader();
                dr.Read();

                if (dr.HasRows)
                {

                    bunifuCircleProgressbar1.Visible = true;
                    flatLabel4.Visible = true;



                    for (int i = 1; i <= 100; i++)
                    {
                        Thread.Sleep(15);
                        bunifuCircleProgressbar1.Value = i;
                        bunifuCircleProgressbar1.Update();

                    }

                    role = dr.GetValue(11).ToString();

                    Form1 fr = new Form1(role);
                    fr.Show();
                    this.Hide();
                    con.Close();
                    Log();
                   // cmd = new MySqlCommand("INSERT INTO `tblhistory`(`Username`, `Date`, `TimeLogIn`) values ('" + txtUser.Text + "','" + lblDateTime.Text + "', '" + lblTime.Text + "')", con);
                    //cmd.ExecuteNonQuery();
                  



                }
                else
                {

                    MessageBox.Show("Invalid Password");
                    MessageBox.Show("There was a problem in opening you database check is it open or close you", "This system will automatically restart");
                    Login lg = new Login();
                    lg.Show();
                    this.Hide();

                }
            }
            catch (Exception ex)
            {
                return;
            }
            finally
            {
                con.Close();
                con.Dispose();

            }
            
            
            
          




            //try
            //{
            //    pictureBox1.Visible = false;
            //    flatLabel4.Visible = true;
            //    con.Open();
            //    cmd = new MySqlCommand("Select * from tblstaff where Username like '" + txtUser.Text + "' and Password like '" + txtPassword.Text + "'", con);
            //    cmd.ExecuteNonQuery();
            //    dr = cmd.ExecuteReader();
            //    dr.Read();

            //    if (dr.HasRows)
            //    {

            //        bunifuCircleProgressbar1.Visible = true;
            //        flatLabel4.Visible = true;



            //        for (int i = 1; i <= 100; i++)
            //        {
            //            Thread.Sleep(15);
            //            bunifuCircleProgressbar1.Value = i;
            //            bunifuCircleProgressbar1.Update();

            //        }

            //        role = dr.GetValue(11).ToString();

            //        Form1 fr = new Form1(role);
            //        fr.Show();
            //        this.Hide();
            //        con.Close();
            //        con.Open();
            //        cmd = new MySqlCommand("INSERT INTO `tblhistory`(`Username`, `Date`, `TimeLogIn`) values ('" + txtUser.Text + "','" + lblDateTime.Text + "', '" + lblTime.Text + "')", con);
            //        cmd.ExecuteNonQuery();
            //        con.Close();



            //    }
            //    else
            //    {

            //        MessageBox.Show("Invalid Password");
            //        MessageBox.Show("There was a problem in opening you database check is it open or close you", "This system will automatically restart");
            //        Login lg = new Login();
            //        lg.Show();
            //        this.Hide();

            //    }
            //}
            //catch (Exception ex)
            //{
            //    return;
            //}
            //finally
            //{
            //    con.Close();
            //    con.Dispose();

            //}

           // LoginForm();
        }

        private void bunifuFlatButton1_KeyDown(object sender, KeyEventArgs e)
        {
            Loa();
        }
        }
    }


