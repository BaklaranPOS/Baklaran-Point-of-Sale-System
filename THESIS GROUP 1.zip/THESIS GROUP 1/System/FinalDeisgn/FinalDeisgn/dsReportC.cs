﻿namespace FinalDeisgn
{


    public partial class dsReportC
    {
        partial class DataTable3DataTable
        {
       }
    
        partial class DataTable1DataTable
        {
        }

        partial class DailySalesByStaffDataTable
        {

        }
    }
}
